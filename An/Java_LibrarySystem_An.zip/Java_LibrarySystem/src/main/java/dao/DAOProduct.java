package dao;

import java.io.UnsupportedEncodingException;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.swing.JOptionPane;

import common.ConnectToProperties;
import common.Convertor;
import entity.*;

public class DAOProduct {
	
	public static List<BookDetail> getAllBook() {
		List<BookDetail> books = new ArrayList<BookDetail>();
		try (
			var con = DriverManager.getConnection(ConnectToProperties.getConnection());
			var ps	= con.prepareCall("{Call getAllBook}");
			var rs	= ps.executeQuery();
		) {
		while(rs.next()) {
			var book = new BookDetail();
			book.setBookNo(rs.getInt("BookNo"));
			book.setTitle(rs.getString("Title"));
			book.setAuthor(rs.getString("Author"));
			book.setPublisher(rs.getString("Publisher"));
			book.setYPublished(rs.getDate("YPublished"));
			book.setDescription(rs.getString("Description"));
			book.setISBN(rs.getString("ISBN"));
			book.setPages(rs.getInt("Pages"));
			book.setShelfNo(rs.getInt("ShelfNo"));
			book.setStatus(rs.getBoolean("Status"));
			books.add(book);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
		}
		return books;
	}
	
	public static List<Category> getAllCategory() {
		List<Category> category = new ArrayList<Category>();
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getAllCategory}");
				var rs	= ps.executeQuery();
			) {
			while(rs.next()) {
				var cat = new Category();
				cat.setCategoryNo(rs.getInt("CategoryNo"));
				cat.setCategoryName(rs.getString("CategoryName"));
				category.add(cat);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
			return category;
	}
	
	public static String getBookCover(int BookNo) {
		String image = null;
		byte[] stored_img = null;
		
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getBookCover(?)}");
			) {
				ps.setInt(1, BookNo);
				
				var rs = ps.executeQuery();
				while(rs.next()) {
					stored_img = rs.getBytes("ImgLink");				
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		
		image = getImg(stored_img);
		return image;
	}
	
	public static List<BookDetail> getBookbyGenre(List<String> CategoryName) {
		List<BookDetail> books = new ArrayList<BookDetail>();
		String arr = "";
		var j = 0;
		for(var i : CategoryName) {
			if(j == 0) {
				arr += i;
			} else {
				arr += "," + i;
			}
			j++;
		}
		
		try (
			var con = DriverManager.getConnection(ConnectToProperties.getConnection());
			var	ps	= con.prepareCall("{Call getBookbyGenre(?)}");
		) { 

			ps.setString(1, arr);
			
			var rs = ps.executeQuery();
			
			while(rs.next()) {

				var book = new BookDetail();
				book.setBookNo(rs.getInt("BookNo"));
				book.setTitle(rs.getString("Title"));
				book.setAuthor(rs.getString("Author"));
				book.setPublisher(rs.getString("Publisher"));
				book.setYPublished(rs.getDate("YPublished"));
				book.setDescription(rs.getString("Description"));
				book.setISBN(rs.getString("ISBN"));
				book.setPages(rs.getInt("Pages"));
				book.setShelfNo(rs.getInt("ShelfNo"));
				book.setStatus(rs.getBoolean("Status"));
				books.add(book);

			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
		}

		return books;
	}
	
	public static List<BookDetail> getBookRecord(int BookNo) {
		List<BookDetail> record = new ArrayList<BookDetail>();
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getBookRecord(?)}");
			) {
			
				ps.setInt(1, BookNo);
				
				var rs = ps.executeQuery();
				
				while(rs.next()) {
					var book = new BookDetail();
					book.setBookNo(rs.getInt("BookNo"));
					book.setTitle(rs.getString("Title"));
					book.setAuthor(rs.getString("Author"));
					book.setPublisher(rs.getString("Publisher"));
					book.setYPublished(rs.getDate("YPublished"));
					book.setDescription(rs.getString("Description"));
					book.setISBN(rs.getString("ISBN"));
					book.setPages(rs.getInt("Pages"));
					book.setShelfNo(rs.getInt("ShelfNo"));
					book.setStatus(rs.getBoolean("Status"));
					record.add(book);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		return record;
	}
	
	public static String getShelf(int ShelfNo) {
		String location = null;
		
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getShelfLocation(?)}");
			) {
			
				ps.setInt(1, ShelfNo);
				
				var rs = ps.executeQuery();
				
				while(rs.next()) {
					location = rs.getString("ShelfName");
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		
		return location;
	}
	
	public static int getShelfNo(String ShelfName) {
		int s_no = 0;
		
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getShelfNo(?)}");
			) {
			
				ps.setString(1, ShelfName);
				
				var rs = ps.executeQuery();
				
				while(rs.next()) {
					s_no = rs.getInt("ShelfNo");
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		
		return s_no;
	}
	
	public static List<ImageLink> getBookImg(int BookNo) {
		List<ImageLink> img = new ArrayList<ImageLink>();
		try(
			var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			var ps = connection.prepareCall("{Call getBookImg(?)}");
			) {
		ps.setInt(1, BookNo);
		var rs = ps.executeQuery();
		while (rs.next()) {
			var img_link = new ImageLink();
			img_link.setBookNo(rs.getInt("BookNo"));
			img_link.setImgNo(rs.getInt("ImgNo"));
			img_link.setImgLink(rs.getBytes("ImgLink"));
			img_link.setIsCover(rs.getBoolean("IsCover"));
			img_link.setStatus(rs.getBoolean("Status"));
			
			img.add(img_link);
		}
	} catch (Exception e) {
		JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}		
		return img;
	}
	
	public static String getImg(byte[] stored_img) {
		String img = null;

		try {
			img = new String(stored_img, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return img;
	}
	
	public static List<BookItem> getBookItem(int BookNo) {
		List<BookItem> item = new ArrayList<BookItem>();
		try (
				var con = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps	= con.prepareCall("{Call getBookItem(?)}");
			) {
			
				ps.setInt(1, BookNo);
				
				var rs = ps.executeQuery();
				
				while(rs.next()) {
					var book = new BookItem();
					book.setItemNo(rs.getInt("ItemNo"));
					book.setBookNo(rs.getInt("BookNo"));
					book.setBookID(rs.getString("BookID"));
					book.setStatus(rs.getBoolean("Status"));
					item.add(book);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
			}
		return item;
	}
 	
	public static void reserveBook(String bookID, String libraryID) {
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
			var ps1 = connection.prepareCall("{Call getAccountInfo(?)}");
			ps1.setString(1, libraryID);
			var getAcc = ps1.executeQuery();
			var AccountNo = getAcc.getInt("AccountNo");
			
			var ps2 = connection.prepareCall("{Call getItemNo(?)}");
			var getItemNo = ps2.executeQuery();
			var ItemNo = getItemNo.getInt("ItemNo");
			
			var ps3 = connection.prepareCall("{Call reserveBook(?, ?)}");
			ps3.setInt(1, ItemNo);
			ps3.setInt(2, AccountNo);
			
			ps3.execute();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}	
	}
	
	public static String getAccountName(int AccountNo) {
		String accountName = null;
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call getaccountName(?)}");
				) {
			
			ps.setInt(1, AccountNo);
			var rs = ps.executeQuery();
			while(rs.next()) {
				accountName = rs.getString("Account Name");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}	
		
		return accountName;
	}
	
	public static int getBookCategory(String CategoryName) {
		var categoryNo = 0;
		try (
			var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			var ps = connection.prepareCall("{Call getBookCategory(?)}")
			) {
			ps.setString(1, CategoryName);
			var rs = ps.executeQuery();
			while (rs.next()) {
				categoryNo = rs.getInt("CategoryNo");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}
		
		return categoryNo;
	}

		
	public static void addNewBook(String title, String author, String publisher, String isbn, String dPublished, String description, int page, int shelfno, String bookCover, String bookImg, String genre){
		try (
			var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			var ps = connection.prepareCall("{Call addNewBook(?,?,?,?,?,?,?,?)}");
				) {
			java.sql.Date date = null;
			try {
				date = new java.sql.Date(new SimpleDateFormat("yyyy-MM-fsrwdd").parse(dPublished).getTime());
			} catch (Exception e1) {
				e1.getMessage();
			}
			ps.setString(1, title);
			ps.setString(2, author);
			ps.setString(3, publisher);
			ps.setString(4, isbn);
			ps.setDate(5, date);
			ps.setString(6, description);
			ps.setInt(7, page);
			ps.setInt(8, shelfno);
			var detail_count = ps.executeUpdate();
			
			var book = new BookDetail();
			
			var getNewInsert = connection.prepareCall("{Call getBookNo(?)}");
			getNewInsert.setString(1, isbn);
			var rs = getNewInsert.executeQuery();
			while(rs.next()) {	
				book.setBookNo(rs.getInt("BookNo"));
			}
			
			var bookNo = book.getBookNo();
			var convert = new Convertor();
			var addBookCover = connection.prepareCall("{Call addBookCover(?,?)}");
			addBookCover.setBytes(1, convert.getImgByte(bookCover));
			addBookCover.setInt(2, bookNo);
			var cover_count = addBookCover.executeUpdate();
			
			var img_count = 0;
			String[] arrImg = bookImg.split("; ", -1);
			for(var img : arrImg) {
				var addBookImg = connection.prepareCall("{Call addBookImg(?,?)}");
				addBookImg.setBytes(1, convert.getImgByte(img));
				addBookImg.setInt(2, bookNo);
				var count = addBookImg.executeUpdate();
				if(count > 0) {
					img_count++;
				}
			}
			
			var genre_count = 0;
			String[] arrGenre = genre.split("; ", -1);
			for(var cate : arrGenre) {
				var addBookCategory = connection.prepareCall("{Call addBookGenre(?,?)}");
				addBookCategory.setInt(1, getBookCategory(cate));
				addBookCategory.setInt(2, bookNo);
				var count = addBookCategory.executeUpdate();
				if(count > 0) {
					genre_count++;
				}
			}
			
			var msg = "";
			if(detail_count > 0 && cover_count > 0 && img_count > 0 && genre_count > 0) {
				msg = "New book is successfull added.";
			} else {
				msg = "Failed adding new book. Please fill in all required field(s).";
			}
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void AddCopy(int bookNo, String bookID) {
		
		try (
			var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			var ps = connection.prepareCall("{Call AddCopy(?,?)}");
			) {
			
			ps.setInt(1, bookNo);
			ps.setString(2, bookID);
			
			var count = ps.executeUpdate();
			var msg = "";
			if(count > 0) {
				msg =  "New copy is successfully added";
			} else {
				msg = "Failed adding new copy.";
			}
			JOptionPane.showMessageDialog(null, msg);
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static List<Shelf> getAllShelf() {
		List<Shelf> shelf = new ArrayList<Shelf>();
		
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call getAllShelf}");
				var rs = ps.executeQuery();
					) {
				while(rs.next()) {
					var s = new Shelf();
					s.setShelfNo(rs.getInt("ShelfNo"));
					s.setShelfName(rs.getString("ShelfName"));
					s.setStatus(rs.getBoolean("Status"));
					shelf.add(s);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		
		return shelf;
	}
	
	public static int getCopyNo(int bookNo) {
		var no_copy = 0;
		
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call getBookCopy(?)}");
					) {
			ps.setInt(1, bookNo);
			
			var rs = ps.executeQuery();
			
			while(rs.next()) {
				no_copy = rs.getInt("noCopy");
			}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		
		return no_copy;
	}

	public static void deleteCopy(String bookID) {
		
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call deleteCopy(?)}");
					) {
			ps.setString(1, bookID);
			
			var result = ps.executeUpdate();
			
			if(result > 0) {
				var msg = "Successfully deleted copy " + bookID;
				JOptionPane.showMessageDialog(null, msg);
			}
			
		} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
	}
	
public static void deleteBook(int bookNo) {
		
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call deleteBook(?)}");
					) {
			ps.setInt(1, bookNo);
			
			var result = ps.executeUpdate();
			
			if(result > 0) {
				var msg = "Successfully deleted";
				JOptionPane.showMessageDialog(null, msg);
			}
			
		} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
	}
	
	//Chi Nga
	public static List<Account> accountsList() {
		List<Account> accountsList = new ArrayList<Account>();
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
		) {
			String query = "SELECT * FROM Account WHERE IsAdmin = 0";
			PreparedStatement st = connection.prepareStatement(query);
			ResultSet rs = st.executeQuery();
			while(rs.next()) {
				var account = new Account();
				account.setAccountNo(rs.getInt("AccountNo"));
				account.setAccountName(rs.getString("AccountName"));
				account.setLibraryID(rs.getString("LibraryID"));
				account.setPassword(rs.getString("Password"));
				account.setIsAdmin(rs.getBoolean("IsAdmin"));
				account.setDJoined(rs.getDate("DJoined"));
				account.setDExpired(rs.getDate("DExpired"));
				account.setPoints(rs.getInt("Points"));
				account.setStatus(rs.getBoolean("Status"));
				accountsList.add(account);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return accountsList;
	}
	
}