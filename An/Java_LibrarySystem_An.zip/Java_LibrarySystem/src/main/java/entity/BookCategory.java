package entity;

public class BookCategory {
	private int CategoryNo;
	private int BookNo;
		
	public BookCategory() {}
	
	public BookCategory(int categoryNo, int bookNo) {
		CategoryNo = categoryNo;
		BookNo = bookNo;
	}

	public int getCategoryNo() {
		return CategoryNo;
	}

	public void setCategoryNo(int categoryNo) {
		CategoryNo = categoryNo;
	}

	public int getBookNo() {
		return BookNo;
	}

	public void setBookNo(int bookNo) {
		BookNo = bookNo;
	}

	@Override
	public String toString() {
		return "BookCategory [CategoryNo=" + CategoryNo + ", BookNo=" + BookNo + "]";
	}
}
