package entity;

import java.util.Date;

public class Reservation {
	private int ReserveNo;
	private int AccountNo;
	private int ItemNo;
	private Date DReserve;
	private boolean Status;
	
	public Reservation() {}

	public Reservation(int reserveNo, int accountNo, int itemNo, Date dReserve, boolean status) {
		ReserveNo = reserveNo;
		AccountNo = accountNo;
		ItemNo = itemNo;
		DReserve = dReserve;
		Status = status;
	}

	public int getReserveNo() {
		return ReserveNo;
	}

	public void setReserveNo(int reserveNo) {
		ReserveNo = reserveNo;
	}

	public int getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}

	public int getItemNo() {
		return ItemNo;
	}

	public void setItemNo(int itemNo) {
		ItemNo = itemNo;
	}

	public Date getDReserve() {
		return DReserve;
	}

	public void setDReserve(Date dReserve) {
		DReserve = dReserve;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "Reservation [ReserveNo=" + ReserveNo + ", AccountNo=" + AccountNo + ", ItemNo=" + ItemNo + ", DReserve="
				+ DReserve + ", Status=" + Status + "]";
	}
}
