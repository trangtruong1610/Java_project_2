package view;

import common.ConnectToProperties;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.border.SoftBevelBorder;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Account_LoginForm extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	private JLabel lblNewLabel;
	private JPasswordField passwordField;
	private JLabel lblmessage;
	private static Account_LoginForm frame;
	private JLabel create;
	private JButton btnLogin;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
//		try {
//			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
//		} catch (Throwable e) {
//			e.printStackTrace();
//		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Account_LoginForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Account_LoginForm() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 180, 750, 350);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		username = new JTextField();
		username.setFont(new Font("Tahoma", Font.PLAIN, 15));
		username.setBounds(300, 127, 200, 20);
		contentPane.add(username);
		username.setColumns(10);
		
		JLabel id = new JLabel("");
		id.setHorizontalAlignment(SwingConstants.CENTER);
		id.setIcon(new ImageIcon(new ImageIcon("image/icons/lib-id.png").getImage()));
		id.setBounds(230, 107, 60, 50);
		contentPane.add(id);
		
		JLabel password = new JLabel("");
		password.setHorizontalAlignment(SwingConstants.CENTER);
		password.setIcon(new ImageIcon(new ImageIcon("image/icons/uPass.png").getImage()));
		password.setBounds(230, 176, 60, 15);
		contentPane.add(password);
		
		JLabel lblLogin = new JLabel(" LOGIN");
		lblLogin.setIcon(new ImageIcon(new ImageIcon("image/icons/Book-icon.png").getImage()));
		lblLogin.setForeground(new Color(255, 255, 255));
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblLogin.setBounds(300, 70, 200, 39);
		contentPane.add(lblLogin);
		
		lblNewLabel = new JLabel("X");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		lblNewLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(722, 0, 28, 20);
		contentPane.add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(300, 176, 200, 20);
		contentPane.add(passwordField);
		
		lblmessage = new JLabel("Invalid Username OR Password");
		lblmessage.setForeground(new Color(255, 99, 71));
		lblmessage.setBounds(300, 207, 200, 14);
		contentPane.add(lblmessage);
		
		create = new JLabel("Sign up to create your account");
		create.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Account_RegisterForm field = new Account_RegisterForm();
				field.setVisible(true);
				setVisible(false);
			}
		});
		create.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		create.setForeground(new Color(0, 191, 255));
		create.setBounds(299, 256, 201, 14);
		contentPane.add(create);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLoginActionPerformed(e);
			}
		});
		btnLogin.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnLogin.setForeground(new Color(255, 255, 255));
		btnLogin.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
		btnLogin.setBackground(new Color(255, 127, 80));
		btnLogin.setContentAreaFilled(true);
		btnLogin.setBounds(300, 225, 90, 25);
		contentPane.add(btnLogin);
		lblmessage.setVisible(false);
		
		
		setUndecorated(true);
	}
	protected void btnLoginActionPerformed(ActionEvent e) {
		try (
			var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			) {
			String query = "Select * from Account where AccountName=? and Password=?";
			PreparedStatement pst = connection.prepareStatement(query);
			pst.setString(1, username.getText());
			pst.setString(2, passwordField.getText());
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				if(rs.getBoolean("IsAdmin")){
					Account_AccountManagement field = new Account_AccountManagement();
					field.setVisible(true);
					setVisible(false);
				}else{
					Account_MemberPage field = new Account_MemberPage();
					field.setVisible(true);
					setVisible(false);
				}
			}else{
				lblmessage.setVisible(true);
				username.setText("");
				passwordField.setText("");
				username.requestFocus();
			}
			connection.close();
		} catch (SQLException error) {
			System.out.println(error.getMessage());
		}
	}
}
