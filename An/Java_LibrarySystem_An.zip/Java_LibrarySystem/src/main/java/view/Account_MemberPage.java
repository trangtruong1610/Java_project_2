package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class Account_MemberPage extends JFrame {

	private JPanel contentPane;
	private static String accountNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		accountNo = args[0];
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Account_MemberPage frame = new Account_MemberPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Account_MemberPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Member Page!");
		lblNewLabel.setBounds(90, 118, 97, 14);
		contentPane.add(lblNewLabel);
	}

}
