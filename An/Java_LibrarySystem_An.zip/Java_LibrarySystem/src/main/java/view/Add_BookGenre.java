package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;

import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JCheckBox;
import javax.swing.border.BevelBorder;
import javax.swing.border.SoftBevelBorder;

import dao.DAOProduct;

import javax.swing.border.MatteBorder;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JLabel;

public class Add_BookGenre extends JFrame {

	private JPanel contentPane;
	private JButton btnOK;
	private JButton btnCancel;
	private JScrollPane scrollPane;
	private JPanel panel;
	private static String accountNo;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if(args.length != 0) {
			accountNo = args[0];
		} else {
			accountNo = null;
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_BookGenre frame = new Add_BookGenre();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_BookGenre() {
		setTitle("Choose Book Genre");
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 480);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setContentPane(contentPane);
		
		btnOK = new JButton("OK");
		btnOK.setForeground(new Color(245, 245, 245));
		btnOK.setBounds(31, 387, 82, 26);
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnOK(e);
			}
		});
		btnOK.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		btnOK.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnOK.setBackground(new Color(255, 140, 0));
		
		btnCancel = new JButton("Cancel");
		btnCancel.setForeground(new Color(245, 245, 245));
		btnCancel.setBounds(134, 387, 82, 26);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancel(e);
			}
		});
		btnCancel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		btnCancel.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCancel.setBackground(new Color(255, 140, 0));
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBounds(31, 37, 651, 339);
		scrollPane.setBackground(new Color(245, 245, 245));
		
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(20, 20, 20, 20));
		scrollPane.setViewportView(panel);
		panel.setLayout(new GridLayout(0, 3, 20, 5));
		contentPane.add(scrollPane);
		contentPane.add(btnOK);
		contentPane.add(btnCancel);
		chooseBookGenres();
	}
	
	private void chooseBookGenres() {
		for(var cat : DAOProduct.getAllCategory()) {
			var chkbox = new JCheckBox();
			chkbox.setText(cat.getCategoryName());
			chkbox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
			chkbox.setForeground(new Color(105,105,105));
			panel.add(chkbox);
		}
	}
	
	public String getGenres() {
		String genres = "";
		
		Component[] component = panel.getComponents();
		var j = 0;
		for(int i = 0; i < component.length; i++) {
			JCheckBox chkbox = (JCheckBox) component[i];
			if(chkbox.isSelected()) {
				if(j == 0) {
					genres += chkbox.getText();
				} else {
					genres += ", " + chkbox.getText();
				}
				j++;
			}	
		}
		
		return genres;
	}
		
	protected void btnOK(ActionEvent e) {
		var genreArr = getGenres();
		
		String[] arr = new String[2];
		arr[0] = accountNo;
		arr[1] = genreArr;
		
		Add_NewBook.main(arr);
		
		
		this.setVisible(false);
	}
	
	protected void btnCancel(ActionEvent e) {
		int result = JOptionPane.showConfirmDialog(null, "Unsaved choices will be discarded. Do you still want to cancel?", "Confirmation", JOptionPane.YES_NO_OPTION);
		switch(result) {
		case JOptionPane.YES_OPTION:
			dispose();
			this.setVisible(false);
		case JOptionPane.NO_OPTION:
			break;
		}
	}

}
