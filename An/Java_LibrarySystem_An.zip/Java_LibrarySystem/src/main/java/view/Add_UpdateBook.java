package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.CardLayout;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;
import javax.swing.BoxLayout;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add_UpdateBook extends JFrame {

	private JPanel contentPane;
	private static String accountNo;
	private static String bookNo;
	private JPanel panelDetail;
	private JLabel lblTitle;
	private JLabel lblAuthor;
	private JLabel lblPublisher;
	private JLabel lblIsbn;
	private JLabel lblDate;
	private JLabel lblGenre;
	private JLabel lblPages;
	private JLabel lblShelf;
	private JLabel lblBookCover;
	private JLabel lblBookImg;
	private JLabel lblDescription;
	private JTextField txtISBN;
	private JDateChooser dateChooser;
	private JTextField txtTitle;
	private JPanel panel;
	private JLabel lblCover;
	private JTextField txtAuthor;
	private JTextField txtPublisher;
	private JTextField txtPage;
	private JComboBox comboBox;
	private JButton btnGenre;
	private JButton btnCover;
	private JButton btnImg;
	private JTextField txtCover;
	private JTextField txtImg;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JButton btnSave;
	private JButton btnCancel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if(args.length != 0) {
			accountNo = args[0];
			bookNo = args[1];
		} else {
			accountNo = null;
			bookNo = null;
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_UpdateBook frame = new Add_UpdateBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_UpdateBook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 640);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		panelDetail = new JPanel();
		panelDetail.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panelDetail.setBackground(new Color(51, 51, 51));
		contentPane.add(panelDetail, "name_518979939800200");
		panelDetail.setLayout(null);
		
		lblTitle = new JLabel("Book Title");
		lblTitle.setForeground(new Color(245, 245, 245));
		lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblTitle.setBounds(55, 29, 65, 25);
		panelDetail.add(lblTitle);
		
		lblAuthor = new JLabel("Author");
		lblAuthor.setForeground(new Color(245, 245, 245));
		lblAuthor.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblAuthor.setBounds(55, 65, 65, 25);
		panelDetail.add(lblAuthor);
		
		lblPublisher = new JLabel("Publisher");
		lblPublisher.setForeground(new Color(245, 245, 245));
		lblPublisher.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblPublisher.setBounds(55, 101, 65, 25);
		panelDetail.add(lblPublisher);
		
		lblIsbn = new JLabel("ISBN");
		lblIsbn.setForeground(new Color(245, 245, 245));
		lblIsbn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblIsbn.setBounds(55, 137, 65, 25);
		panelDetail.add(lblIsbn);
		
		lblDate = new JLabel("Published Date");
		lblDate.setForeground(new Color(245, 245, 245));
		lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblDate.setBounds(348, 137, 78, 25);
		panelDetail.add(lblDate);
		
		lblGenre = new JLabel("Genre");
		lblGenre.setForeground(new Color(245, 245, 245));
		lblGenre.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblGenre.setBounds(55, 173, 65, 25);
		panelDetail.add(lblGenre);
		
		lblPages = new JLabel("Pages");
		lblPages.setForeground(new Color(245, 245, 245));
		lblPages.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblPages.setBounds(349, 210, 78, 25);
		panelDetail.add(lblPages);
		
		lblShelf = new JLabel("Shelf");
		lblShelf.setForeground(new Color(245, 245, 245));
		lblShelf.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblShelf.setBounds(56, 210, 65, 25);
		panelDetail.add(lblShelf);
		
		lblBookCover = new JLabel("Book Cover");
		lblBookCover.setForeground(new Color(245, 245, 245));
		lblBookCover.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblBookCover.setBounds(55, 246, 65, 25);
		panelDetail.add(lblBookCover);
		
		lblBookImg = new JLabel("Book Image");
		lblBookImg.setForeground(new Color(245, 245, 245));
		lblBookImg.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblBookImg.setBounds(55, 282, 65, 25);
		panelDetail.add(lblBookImg);
		
		lblDescription = new JLabel("Description");
		lblDescription.setForeground(new Color(245, 245, 245));
		lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblDescription.setBounds(55, 318, 65, 25);
		panelDetail.add(lblDescription);
		
		txtISBN = new JTextField();
		txtISBN.setEditable(false);
		txtISBN.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtISBN.setBounds(132, 140, 190, 20);
		panelDetail.add(txtISBN);
		txtISBN.setColumns(10);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(436, 140, 190, 20);
		panelDetail.add(dateChooser);
		
		txtTitle = new JTextField();
		txtTitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtTitle.setEditable(false);
		txtTitle.setColumns(10);
		txtTitle.setBounds(132, 32, 496, 20);
		panelDetail.add(txtTitle);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(new Color(220, 220, 220));
		panel.setBounds(679, 29, 270, 350);
		panelDetail.add(panel);
		panel.setLayout(null);
		
		lblCover = new JLabel("");
		lblCover.setHorizontalAlignment(SwingConstants.CENTER);
		lblCover.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCover.setBounds(0, 0, 270, 350);
		panel.add(lblCover);
		
		txtAuthor = new JTextField();
		txtAuthor.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtAuthor.setEditable(false);
		txtAuthor.setColumns(10);
		txtAuthor.setBounds(132, 68, 496, 20);
		panelDetail.add(txtAuthor);
		
		txtPublisher = new JTextField();
		txtPublisher.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtPublisher.setEditable(false);
		txtPublisher.setColumns(10);
		txtPublisher.setBounds(132, 104, 496, 20);
		panelDetail.add(txtPublisher);
		
		txtPage = new JTextField();
		txtPage.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtPage.setEditable(false);
		txtPage.setColumns(10);
		txtPage.setBounds(437, 212, 190, 20);
		panelDetail.add(txtPage);
		
		comboBox = new JComboBox();
		comboBox.setBounds(132, 212, 189, 23);
		panelDetail.add(comboBox);
		
		btnGenre = new JButton("Select");
		btnGenre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnGenreActionPerformed(e);
			}
		});
		btnGenre.setBackground(new Color(255, 140, 0));
		btnGenre.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnGenre.setForeground(new Color(220, 220, 220));
		btnGenre.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnGenre.setBounds(132, 174, 89, 23);
		panelDetail.add(btnGenre);
		
		btnCover = new JButton("Choose File");
		btnCover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCoverActionPerformed(e);
			}
		});
		btnCover.setForeground(new Color(220, 220, 220));
		btnCover.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnCover.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCover.setBackground(new Color(255, 140, 0));
		btnCover.setBounds(132, 248, 89, 23);
		panelDetail.add(btnCover);
		
		btnImg = new JButton("Choose Files");
		btnImg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnImgActionPerformed(e);
			}
		});
		btnImg.setForeground(new Color(220, 220, 220));
		btnImg.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnImg.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnImg.setBackground(new Color(255, 140, 0));
		btnImg.setBounds(132, 284, 89, 23);
		panelDetail.add(btnImg);
		
		txtCover = new JTextField();
		txtCover.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtCover.setEditable(false);
		txtCover.setColumns(10);
		txtCover.setBounds(229, 249, 397, 20);
		panelDetail.add(txtCover);
		
		txtImg = new JTextField();
		txtImg.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtImg.setEditable(false);
		txtImg.setColumns(10);
		txtImg.setBounds(229, 285, 397, 20);
		panelDetail.add(txtImg);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(130, 318, 496, 174);
		panelDetail.add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSaveActionPerformed(e);
			}
		});
		btnSave.setForeground(new Color(220, 220, 220));
		btnSave.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnSave.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnSave.setBackground(new Color(30, 144, 255));
		btnSave.setBounds(55, 524, 89, 23);
		panelDetail.add(btnSave);
		
		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancelActionPerformed(e);
			}
		});
		btnCancel.setForeground(new Color(220, 220, 220));
		btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnCancel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCancel.setBackground(new Color(30, 144, 255));
		btnCancel.setBounds(180, 524, 89, 23);
		panelDetail.add(btnCancel);
	}
	protected void btnGenreActionPerformed(ActionEvent e) {
	}
	protected void btnCoverActionPerformed(ActionEvent e) {
	}
	protected void btnSaveActionPerformed(ActionEvent e) {
	}
	protected void btnImgActionPerformed(ActionEvent e) {
	}
	protected void btnCancelActionPerformed(ActionEvent e) {
		int result;
	}
}
