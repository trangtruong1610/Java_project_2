package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import common.Convertor;
import dao.DAOProduct;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.SystemColor;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import java.awt.CardLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;
import javax.swing.JSplitPane;
import java.awt.Dimension;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.GridLayout;
import java.awt.FlowLayout;

public class Home_BookItem extends JFrame {

	private JPanel contentPane;
	private static String bookNo;
	private static String accountNo;
	private JMenuBar menuBar;
	private JButton btnLogin;
	private JButton btnAccount;
	private JButton btnLogout;
	private JPanel panelPreview;
	private JPanel panelDetail;
	private JPanel panel;
	private JSplitPane splitPane;
	private JButton btnPrev;
	private JButton btnNext;
	private JTextArea txtTitle;
	private JLabel lblAuthor;
	private JLabel txtAuthor;
	private JLabel lblPublisher;
	private JLabel txtPublisher;
	private JLabel txtISBN;
	private JLabel lblIsbn;
	private JLabel txtDate;
	private JLabel lblPublishedDate;
	private JLabel txtShelf;
	private JLabel lblShelf;
	private JLabel txtPages;
	private JLabel lblPages;
	private JLabel lblDescription;
	private JScrollPane scrollPaneDescription;
	private JTextArea txtDescription;
	private JScrollPane scrollPane;
	private JTable table;
	private JLabel lblBookItem;
	private int b_No;
	private JButton btnBorrow;
	private JButton btnBack;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if(args.length == 1) {
			bookNo = args[0];
		} else if (args.length == 2) {
			accountNo = args[0];
			bookNo = args[1];
		} else {
			bookNo = "13";
			accountNo = null;
		}
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home_BookItem frame = new Home_BookItem();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home_BookItem() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 720);
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));

		b_No = Integer.parseInt(bookNo);
				
		menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.control);
		setJMenuBar(menuBar);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLoginActionPerformed(e);
			}
		});
		btnLogin.setBorder(new EmptyBorder(5, 15, 5, 15));
		btnLogin.setBackground(SystemColor.menu);
		menuBar.add(btnLogin);
		
		btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAccountActionPerformed(e);
			}
		});
		btnAccount.setBorder(new EmptyBorder(5, 15, 5, 15));
		btnAccount.setBackground(SystemColor.menu);
		menuBar.add(btnAccount);
		
		btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLogoutActionPerformed(e);
			}
		});
		btnLogout.setBorder(new EmptyBorder(5, 15, 5, 15));
		btnLogout.setBackground(SystemColor.menu);
		menuBar.add(btnLogout);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		panelPreview = new JPanel();
		panelPreview.setBorder(null);
		panelPreview.setMaximumSize(new Dimension(300, 32767));
		panelPreview.setBackground(new Color(51, 51, 51));
		
		panelDetail = new JPanel();
		panelDetail.setBackground(new Color(51, 51, 51));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(panelPreview, GroupLayout.PREFERRED_SIZE, 214, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panelDetail, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addComponent(panelPreview, GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
				.addComponent(panelDetail, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
		);
		
		panel = new JPanel();
		panel.setBackground(new Color(51, 51, 51));
		
		splitPane = new JSplitPane();
		splitPane.setBackground(new Color(51, 51, 51));
		splitPane.setBorder(null);
		GroupLayout gl_panelPreview = new GroupLayout(panelPreview);
		gl_panelPreview.setHorizontalGroup(
			gl_panelPreview.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelPreview.createSequentialGroup()
					.addGap(10)
					.addComponent(splitPane, GroupLayout.PREFERRED_SIZE, 194, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 214, Short.MAX_VALUE)
		);
		gl_panelPreview.setVerticalGroup(
			gl_panelPreview.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelPreview.createSequentialGroup()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 313, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(splitPane, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(43, Short.MAX_VALUE))
		);
		panel.setLayout(new CardLayout(0, 0));
		
		btnPrev = new JButton("");
		btnPrev.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPrevActionPerformed(e);
			}
		});
		btnPrev.setBackground(new Color(211, 211, 211));
		splitPane.setLeftComponent(btnPrev);
		
		btnNext = new JButton("");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNextActionPerformed(e);
			}
		});
		btnNext.setBackground(new Color(211, 211, 211));
		splitPane.setRightComponent(btnNext);
		splitPane.setDividerLocation(95);
		panelPreview.setLayout(gl_panelPreview);
		
		txtTitle = new JTextArea();
		txtTitle.setForeground(new Color(0, 255, 127));
		txtTitle.setFont(new Font("Elephant", Font.BOLD | Font.ITALIC, 20));
		txtTitle.setLineWrap(true);
		txtTitle.setWrapStyleWord(true);
		txtTitle.setEditable(false);
		txtTitle.setBorder(null);
		txtTitle.setBackground(new Color(51, 51, 51));
		
		lblAuthor = new JLabel("Author");
		lblAuthor.setForeground(new Color(240, 255, 255));
		lblAuthor.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		txtAuthor = new JLabel("");
		txtAuthor.setForeground(new Color(255, 255, 255));
		txtAuthor.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		lblPublisher = new JLabel("Publisher");
		lblPublisher.setForeground(new Color(240, 255, 255));
		lblPublisher.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		txtPublisher = new JLabel("");
		txtPublisher.setForeground(new Color(255, 255, 255));
		txtPublisher.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		txtISBN = new JLabel("");
		txtISBN.setForeground(new Color(255, 255, 255));
		txtISBN.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		lblIsbn = new JLabel("ISBN");
		lblIsbn.setForeground(new Color(240, 255, 255));
		lblIsbn.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		txtDate = new JLabel("");
		txtDate.setForeground(new Color(255, 255, 255));
		txtDate.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		lblPublishedDate = new JLabel("Date");
		lblPublishedDate.setForeground(new Color(240, 255, 255));
		lblPublishedDate.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		txtShelf = new JLabel("");
		txtShelf.setForeground(new Color(255, 255, 255));
		txtShelf.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		lblShelf = new JLabel("Location");
		lblShelf.setForeground(new Color(240, 255, 255));
		lblShelf.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		txtPages = new JLabel("");
		txtPages.setForeground(new Color(255, 255, 255));
		txtPages.setFont(new Font("Segoe UI Semibold", Font.BOLD, 12));
		
		lblPages = new JLabel("Pages");
		lblPages.setForeground(new Color(240, 255, 255));
		lblPages.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		
		scrollPaneDescription = new JScrollPane();
		scrollPaneDescription.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPaneDescription.setBorder(null);
		scrollPaneDescription.setBackground(new Color(51, 51, 51));
		scrollPaneDescription.setFont(new Font("Segoe UI Historic", Font.ITALIC, 12));
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(null);
		
		btnBorrow = new JButton("");
		btnBorrow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnBorrowActionPerformed(e);
			}
		});
		btnBorrow.setBackground(new Color(192, 192, 192));
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnBackActionPerformed(e);
			}
		});
		btnBack.setBackground(new Color(192, 192, 192));
		GroupLayout gl_panelDetail = new GroupLayout(panelDetail);
		gl_panelDetail.setHorizontalGroup(
			gl_panelDetail.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_panelDetail.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addComponent(txtTitle, GroupLayout.PREFERRED_SIZE, 758, GroupLayout.PREFERRED_SIZE)
							.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addGroup(gl_panelDetail.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_panelDetail.createSequentialGroup()
									.addComponent(lblPublisher, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(txtPublisher, GroupLayout.DEFAULT_SIZE, 673, Short.MAX_VALUE))
								.addGroup(gl_panelDetail.createSequentialGroup()
									.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_panelDetail.createSequentialGroup()
											.addComponent(lblIsbn, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(txtISBN, GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE))
										.addGroup(gl_panelDetail.createSequentialGroup()
											.addComponent(lblPublishedDate, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
											.addGap(18)
											.addComponent(txtDate, GroupLayout.PREFERRED_SIZE, 223, GroupLayout.PREFERRED_SIZE)
											.addGap(51)
											.addComponent(lblPages, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.UNRELATED)
											.addComponent(txtPages, GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
											.addGap(42)))
									.addGap(145)))
							.addContainerGap())
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addComponent(lblShelf, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(txtShelf, GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
							.addGap(155))
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
								.addComponent(scrollPaneDescription, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 758, Short.MAX_VALUE)
								.addGroup(Alignment.TRAILING, gl_panelDetail.createSequentialGroup()
									.addComponent(lblAuthor, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(txtAuthor, GroupLayout.DEFAULT_SIZE, 673, Short.MAX_VALUE)))
							.addContainerGap())
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 667, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
								.addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnBorrow, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE))
							.addContainerGap())))
		);
		gl_panelDetail.setVerticalGroup(
			gl_panelDetail.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelDetail.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtTitle, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
					.addGap(11)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAuthor)
						.addComponent(txtAuthor, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
						.addComponent(lblPublisher, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtPublisher, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
						.addComponent(lblIsbn, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtISBN, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblPublishedDate, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtDate, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblPages, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtPages, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
						.addComponent(lblShelf, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE)
						.addComponent(txtShelf, GroupLayout.PREFERRED_SIZE, 16, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(scrollPaneDescription, GroupLayout.PREFERRED_SIZE, 211, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
					.addGroup(gl_panelDetail.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panelDetail.createSequentialGroup()
							.addComponent(btnBorrow)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnBack))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 190, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_panelDetail.linkSize(SwingConstants.VERTICAL, new Component[] {btnBorrow, btnBack});
		gl_panelDetail.linkSize(SwingConstants.HORIZONTAL, new Component[] {btnBorrow, btnBack});
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		lblBookItem = new JLabel("Book Copies");
		lblBookItem.setForeground(new Color(0, 0, 128));
		lblBookItem.setFont(new Font("Segoe UI Black", Font.PLAIN, 12));
		lblBookItem.setBackground(SystemColor.control);
		scrollPane.setColumnHeaderView(lblBookItem);
		
		txtDescription = new JTextArea();
		txtDescription.setEditable(false);
		txtDescription.setTabSize(0);
		txtDescription.setForeground(new Color(240, 255, 255));
		txtDescription.setWrapStyleWord(true);
		txtDescription.setLineWrap(true);
		txtDescription.setFont(new Font("Segoe UI Historic", Font.ITALIC, 13));
		txtDescription.setBorder(null);
		txtDescription.setBackground(new Color(51, 51, 51));
		scrollPaneDescription.setViewportView(txtDescription);
		
		lblDescription = new JLabel("Description");
		lblDescription.setBackground(new Color(51, 51, 51));
		scrollPaneDescription.setColumnHeaderView(lblDescription);
		scrollPaneDescription.getColumnHeader().setBackground(new Color(51, 51, 51));
		lblDescription.setForeground(new Color(240, 255, 255));
		lblDescription.setFont(new Font("Segoe UI Semibold", Font.BOLD | Font.ITALIC, 12));
		panelDetail.setLayout(gl_panelDetail);
		contentPane.setLayout(gl_contentPane);
		
		hideBtn(accountNo);
		displayBook();
		try {
			setImg(panel);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		btnPrev.setIcon(setBtnImg("prev.png"));
		btnNext.setIcon(setBtnImg("Next.png"));
		getBookItem(b_No, table);
		btnBorrow.setText(setTextBtnBook());
	}
	
	private void hideBtn(String account) {
		if(account != null) {
			btnLogin.setVisible(false);
			btnAccount.setVisible(true);
			btnLogout.setVisible(true);
		} else {
			btnLogin.setVisible(true);
			btnAccount.setVisible(false);
			btnLogout.setVisible(false);
		}
	}

	private ImageIcon setBtnImg(String img) {
		var path = "image/icons/" + img;
		Image i_icon = new ImageIcon(path).getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		var icon = new ImageIcon(i_icon);
		
		return icon;
	}
	
	private void displayBook() {
		
		for(var book : DAOProduct.getBookRecord(b_No)) {
			setTitle(book.getTitle());
			txtTitle.setText(book.getTitle());
			txtAuthor.setText(book.getAuthor());
			txtPublisher.setText(book.getPublisher());
			txtISBN.setText(book.getISBN());
			txtDate.setText(book.getYPublished().toString());
			txtPages.setText(Integer.toString(book.getPages()));
			txtShelf.setText("Shelf " + DAOProduct.getShelf(book.getShelfNo()));
			txtDescription.setText(book.getDescription());
		}
	}
	
	private void setImg(JPanel pane) throws IOException {
		int b_no = Integer.parseInt(bookNo);
		
		for (var img : DAOProduct.getBookImg(b_no)) {
			var convert = new Convertor();
			var OriginImg = convert.loadImg(DAOProduct.getImg(img.getImgLink()));
			
			var newW = 200;
			var newH = convert.resizeImageWRatioW(OriginImg, newW);
			
			var newImg = new ImageIcon(OriginImg).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);

			var img_label = new JLabel(new ImageIcon(newImg));
			
			pane.add(img_label);			
		}
	}
	
	private String getItemNo(JTable var_table) {
		int row = var_table.getSelectedRow();
			
		String value = var_table.getValueAt(row, 1).toString();
		String valid = var_table.getValueAt(row, 2).toString();
		
		if (valid.equalsIgnoreCase("unavailable")) {
			JOptionPane.showMessageDialog(null, "This book is currently unavailable. Please choose other copies.");
		} else {				
			return value;
		}
		
		return null;
	}
	
	private String setTextBtnBook() {
		String btnContent = null;
		for(var book : DAOProduct.getBookRecord(b_No)) {
			if(book.isStatus() == true) {
				btnContent = "Borrow";
			} else {
				btnContent = "Reserve";
			}
		}
		return btnContent;
	}
	
	private void getBookItem(int BookNo, JTable var_table) {
		var model = new DefaultTableModel();
		model.addColumn("No");
		model.addColumn("Book ID");
		model.addColumn("Book Status");
		var i = 0;
		String status = null;
		for(var item : DAOProduct.getBookItem(BookNo)) {
			if(item.isStatus() == true) {
				status = "Available";
			} else {
				status = "Lent";
			}
			model.addRow(new Object[] {
					i,
					item.getBookID(),
					status
			});
			i++;
		}
		var_table.setModel(model);
	}
		
	private String getBookItem(JTable var_table) {
		int row = var_table.getSelectedRow();
			
		String value = var_table.getValueAt(row, 1).toString();
		String valid = var_table.getValueAt(row, 2).toString();
		
		if (valid.equalsIgnoreCase("lent")) {
			JOptionPane.showMessageDialog(null, "This book is currently lent. Please choose other copy.");
		} else {				
			return value;
		}
		JOptionPane.showMessageDialog(null, value);
		return null;
	}	
	
	protected void btnNextActionPerformed(ActionEvent e) {
		var cardLayout = (CardLayout) panel.getLayout();
		cardLayout.next(panel);
	}
	protected void btnPrevActionPerformed(ActionEvent e) {
		var cardLayout = (CardLayout) panel.getLayout();
		cardLayout.previous(panel);
	}
	protected void btnBorrowActionPerformed(ActionEvent e) {		
		String msg;

		if (table.getSelectionModel().isSelectionEmpty()) {
				msg = "Please select a book.";
		} else {
			var bookItem = getBookItem(table);
			var account = accountNo;
			
			if (account == null) {
				msg = "Please login to reserve/borrow book.";
				//Display Login page
			} else {
				DAOProduct.reserveBook(bookItem, account);
				if (setTextBtnBook().equalsIgnoreCase("Reserve")) {
					msg = "Successfully reserved. We will notify you when the book is available.";
				} else {
					msg = "Successfully reserved. Please go to the counter to get the book. Reservation will be automatically cancelled if not getting confirmation within today.";
				}
			}
		}
		JOptionPane.showMessageDialog(null, msg);
	}
	
	protected void btnBackActionPerformed(ActionEvent e) {
		String[] arr;
		if (accountNo != null) {
			arr = new String[1];
			arr[0] = accountNo;
		} else {
			arr = new String[0];
		}
		
		Home_LibraryHome.main(arr);
		this.setVisible(false);
	}
	protected void btnLogoutActionPerformed(ActionEvent e) {
		String[] arr = new String[0];
		
		this.setVisible(false);
		Home_LibraryHome.main(arr);
	}
	protected void btnAccountActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountNo;
		Account_MemberPage.main(arr);
		this.setVisible(false);
	}
	protected void btnLoginActionPerformed(ActionEvent e) {
		Account_LoginForm.main(null);
		this.setVisible(false);
	}
}
