package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import dao.DAOProduct;
import entity.BookDetail;
import common.Convertor;

import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.Dimension;

import javax.imageio.ImageIO;
import javax.swing.DefaultRowSorter;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Color;
import java.awt.Component;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import net.miginfocom.swing.MigLayout;
import java.awt.GridLayout;
import javax.swing.border.BevelBorder;

public class Home_LibraryHome extends JFrame {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JButton btnLogin;
	private static String accountNo = null;
	private JButton btnAccount;
	private JButton btnLogout;
	private JScrollPane scrollPane_Genre;
	private JScrollPane scrollPane_Book;
	/**
	 * @wbp.nonvisual location=-29,139
	 */
	private JTextField textSearch;
	private JButton btnView;
	private JLabel lblGenre;
	private JButton btnClear;
	private JPanel panel;
	private JTable table;
	private JButton btnSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if (args.length != 0) {
			accountNo = args[0];
		} else {
			accountNo = null;
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home_LibraryHome frame = new Home_LibraryHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home_LibraryHome() {
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
		setTitle("Library Homepage");
				
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 480);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.control);
		setJMenuBar(menuBar);
		
		btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLoginActionPerformed(e);
			}
		});
		btnLogin.setBackground(SystemColor.control);
		menuBar.add(btnLogin);
		
		btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAccountActionPerformed(e);
			}
		});
		btnAccount.setBackground(SystemColor.control);
		menuBar.add(btnAccount);
		
		btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLogoutActionPerformed(e);
			}
		});
		btnLogout.setBackground(SystemColor.control);
		menuBar.add(btnLogout);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.control);
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		
		scrollPane_Genre = new JScrollPane();
		scrollPane_Genre.setBackground(SystemColor.control);
		scrollPane_Genre.setBorder(null);
		
		scrollPane_Book = new JScrollPane();
		scrollPane_Book.setBackground(SystemColor.control);
		scrollPane_Book.setBorder(null);
		
		textSearch = new JTextField();
		textSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SearchBook(e);
			}
		});
		textSearch.setColumns(10);
		
		btnView = new JButton("View Book");
		btnView.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnView.setForeground(new Color(255, 255, 255));
		btnView.setBorder(new BevelBorder(BevelBorder.RAISED, new Color(255, 255, 255), null, new Color(102, 102, 102), null));
		btnView.setContentAreaFilled(true);
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewBook(e);
			}
		});
		btnView.setBackground(new Color(255, 127, 80));
		
		btnClear = new JButton("Clear");
		btnClear.setHorizontalAlignment(SwingConstants.LEADING);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnClearActionPerformed(e);
			}
		});
		btnClear.setForeground(new Color(0, 51, 102));
		btnClear.setFont(new Font("Tahoma", Font.ITALIC, 12));
		btnClear.setBackground(SystemColor.control);
		btnClear.setBorder(null);
		
		btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSearchActionPerformed(e);
			}
		});
		btnSearch.setHorizontalAlignment(SwingConstants.LEADING);
		btnSearch.setForeground(new Color(0, 51, 102));
		btnSearch.setFont(new Font("Tahoma", Font.ITALIC, 12));
		btnSearch.setBorder(null);
		btnSearch.setBackground(SystemColor.menu);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane_Genre, GroupLayout.PREFERRED_SIZE, 187, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnClear, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(textSearch, GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnView, GroupLayout.PREFERRED_SIZE, 79, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane_Book, GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnView)
						.addComponent(textSearch, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnSearch, GroupLayout.PREFERRED_SIZE, 15, GroupLayout.PREFERRED_SIZE)
							.addComponent(btnClear)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane_Genre, GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
						.addComponent(scrollPane_Book, GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)))
		);
		gl_contentPane.linkSize(SwingConstants.VERTICAL, new Component[] {textSearch, btnView});
		
		table = new JTable();
		table.setAutoCreateRowSorter(true);
		scrollPane_Book.setViewportView(table);
		
		lblGenre = new JLabel("Genres");
		lblGenre.setBackground(new Color(102, 102, 102));
		scrollPane_Genre.setColumnHeaderView(lblGenre);
		lblGenre.setHorizontalAlignment(SwingConstants.CENTER);
		lblGenre.setHorizontalTextPosition(SwingConstants.CENTER);
		lblGenre.setForeground(new Color(0, 51, 51));
		lblGenre.setFont(new Font("Elephant", Font.BOLD | Font.ITALIC, 20));
		
		panel = new JPanel();
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(SystemColor.control);
		panel.setFont(new Font("Segoe UI", Font.PLAIN, 10));
		scrollPane_Genre.setViewportView(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		contentPane.setLayout(gl_contentPane);


		hideBtn(accountNo);
		getTableContent(table);
		ResizeTableCol(table);
		addCategory(panel);
	}
	
	private void hideBtn(String account) {
		if(account != null) {
			btnLogin.setVisible(false);
			btnAccount.setVisible(true);
			btnLogout.setVisible(true);
		} else {
			btnLogin.setVisible(true);
			btnAccount.setVisible(false);
			btnLogout.setVisible(false);
		}
	}
	
	private void Search() {
		String search = textSearch.getText();
		DefaultRowSorter<?, ?> sorter = (DefaultRowSorter<?,?>) table.getRowSorter();
		sorter.setRowFilter(RowFilter.regexFilter("(?i)" + search));
		sorter.setSortKeys(null);
		textSearch.setText("");
	}
	
	private void getTableContent(JTable var_table) {
		var model =  (DefaultTableModel) var_table.getModel();
		
		Object[] Columns = new Object[] {"No", "Image", "Title", "Author", "Publisher", "Status"};
		model.setColumnIdentifiers(Columns);
			
		var_table.getColumn("Image").setCellRenderer(new BookCover());
				
		for (var detail : DAOProduct.getAllBook()) {
			var convert = new Convertor();
			var OriginImg = convert.loadImg(DAOProduct.getBookCover(detail.getBookNo()));
			
			var newH = 100;
			var newW = convert.resizeImageWRatioH(OriginImg, newH);
			
			var img = new ImageIcon(OriginImg).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	
			var img_lbl = new JLabel(new ImageIcon(img));
			img_lbl.setHorizontalAlignment(SwingConstants.CENTER);
						
			String status;
			
			if(detail.isStatus() == false) {
				status = "Unavailable";
			} else {
				status = "Available";
			}
			
			model.addRow(new Object[] {
				detail.getBookNo(),
				img_lbl,
				detail.getTitle(),
				detail.getAuthor(),
				detail.getPublisher(),
				status
			});
		}
		
		var_table.setModel(model);
		
		var renderer = (DefaultTableCellRenderer) var_table.getDefaultRenderer(String.class);
		renderer.setHorizontalAlignment(SwingConstants.CENTER);	
		
		var_table.setRowHeight(110);
	}
		
	private static class BookCover extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {							
					
			return (Component) value;
			}
	}
	
	private void ResizeTableCol(JTable var_table) {
		int width = 0;
		int cols = var_table.getColumnCount();
		
		for (int column = 0; column < cols; column++) {
			
			for (int row = 0; row < var_table.getRowCount(); row++) {
			    TableCellRenderer renderer = var_table.getCellRenderer(row, column);
			    Component comp = table.prepareRenderer(renderer, row, column);
			    width = Math.max(comp.getPreferredSize().width, width);
			}
			
			if(column == 0 || column == 1 || column == 5) {
				var_table.getColumnModel().getColumn(column).setMinWidth(100);
				var_table.getColumnModel().getColumn(column).setMaxWidth(width);
			}
		}
	}
	
	private void addCategory(JPanel pane) {
		
		for(var cat : DAOProduct.getAllCategory()) {
			var chkBox = new JCheckBox(cat.getCategoryName());
			chkBox.setFont(new Font("Segoe UI", Font.PLAIN, 11));
			pane.add(chkBox);
		}
	}
	
	private String getBookNo() {
		String bookNo = table.getValueAt(table.getSelectedRow(), 0).toString();						
		return bookNo;
	}
	
	protected void ViewBook(ActionEvent e) {
		if(!table.getSelectionModel().isSelectionEmpty()) {
			String[] arr;
		
			if (accountNo != null) {
				arr = new String[2];
				arr[0] = accountNo;
				arr[1] = getBookNo();
			} else {
				arr = new String[1];
				arr[0] = getBookNo();
			}
			
			Home_BookItem.main(arr);
			this.setVisible(false);
		} else {
			JOptionPane.showMessageDialog(null, "Please select a book to view detail.", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	protected void SearchBook(ActionEvent e) {
		Search();
	}

	protected List<String> getGenreArr() {
		Component[] component = panel.getComponents();
		List<String> genreArr = new ArrayList<>();
		
		for(int i = 0; i < component.length; i++) {
			JCheckBox chkBox = (JCheckBox) component[i];
			if(chkBox.isSelected()) {
				genreArr.add(chkBox.getText());
			}
		}
			    
		return genreArr;
	}

	protected void btnClearActionPerformed(ActionEvent e) {
		Component[] component = panel.getComponents();
		
		for (int i = 0; i < component.length; i++) {
			JCheckBox chkBox = (JCheckBox) component[i];
			chkBox.setSelected(false);
		}
		
		var modelTable = (DefaultTableModel) table.getModel();
		modelTable.setRowCount(0);
		
		getTableContent(table);
	}
	
	protected void btnAccountActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountNo;
		Account_MemberPage.main(arr);
		this.setVisible(false);
	}
	
	protected void btnLogoutActionPerformed(ActionEvent e) {
		accountNo = null;
		var arr = new String[0];
		Home_LibraryHome.main(arr);
	}
	
	protected void btnLoginActionPerformed(ActionEvent e) {
		Account_LoginForm.main(null);
	}
	protected void btnSearchActionPerformed(ActionEvent e) {
		var model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);

		Object[] Columns = new Object[] {"No", "Image", "Title", "Author", "Publisher", "Status"};
		model.setColumnIdentifiers(Columns);
			
		table.getColumn("Image").setCellRenderer(new BookCover());

		for (var detail : DAOProduct.getBookbyGenre(getGenreArr())) {

			var convert = new Convertor();
			var OriginImg = convert.loadImg(DAOProduct.getBookCover(detail.getBookNo()));
			
			var newH = 100;
			var newW = convert.resizeImageWRatioH(OriginImg, newH);
			
			var img = new ImageIcon(OriginImg).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
	
			var img_lbl = new JLabel(new ImageIcon(img));
			img_lbl.setHorizontalAlignment(SwingConstants.CENTER);
						
			String status;

			if(detail.isStatus() == false) {
				status = "Unavailable";
			} else {
				status = "Available";
			}
			
			model.addRow(new Object[] {
				detail.getBookNo(),
				img_lbl,
				detail.getTitle(),
				detail.getAuthor(),
				detail.getPublisher(),
				status
			});
		}
		
		table.setModel(model);
		
		var renderer = (DefaultTableCellRenderer) table.getDefaultRenderer(String.class);
		renderer.setHorizontalAlignment(SwingConstants.CENTER);	
		
		table.setRowHeight(110);
	}
}
