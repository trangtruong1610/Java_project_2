package common;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.imageio.ImageIO;

import org.apache.commons.io.FilenameUtils;

public class Convertor {
	
	public BufferedImage loadImg(String link) {
		BufferedImage image = null;
		
		if(link.startsWith("https://") || link.startsWith("http://")) {
				try {
					image = ImageIO.read(new URL(link));
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		} else {
			try {
				image = ImageIO.read(new File(link));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return image;
	}
	
	public int resizeImageWRatioW(BufferedImage OriginImg, int newW) {
		
		int originW = OriginImg.getWidth();
		int originH = OriginImg.getHeight();
		
		int newH = (newW * originH) / originW;	

		return newH;
	}
	
	public int resizeImageWRatioH(BufferedImage OriginImg, int newH) {
		var originH = OriginImg.getHeight();
		var originW = OriginImg.getWidth();
		
		var newW = (newH * originW) / originH;	

		return newW;
	}
	
	
	public String getImgStr(byte[] stored_img) {
		String img = null;

		try {
			img = new String(stored_img, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return img;
	}
	
	public byte[] getImgByte(String link) {
		byte[] store_img = null;
		
		try {
			var ext = FilenameUtils.getExtension(link);
			var inputStream = loadImg(link);
			var byteArr = new ByteArrayOutputStream();
			ImageIO.write(inputStream, ext, byteArr);
			store_img = byteArr.toByteArray();
		} catch (Exception e) {
			e.getMessage();
		}
		
		return store_img;
	}
	
}
