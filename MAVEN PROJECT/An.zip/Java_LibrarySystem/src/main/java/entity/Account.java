package entity;

import java.util.Date;

public class Account {
	private int AccountNo;
	private String AccountName;
	private String LibraryID;
	private String Password;
	private boolean IsAdmin;
	private Date DJoined;
	private Date DExpired;
	private int Points;
	private boolean Status;
	
	public Account() {}

	public Account(int accountNo, String accountName, String libraryID, String password, boolean isAdmin, Date dJoined,
			Date dExpired, int points, boolean status) {
		AccountNo = accountNo;
		AccountName = accountName;
		LibraryID = libraryID;
		Password = password;
		IsAdmin = isAdmin;
		DJoined = dJoined;
		DExpired = dExpired;
		Points = points;
		Status = status;
	}

	public int getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}

	public String getAccountName() {
		return AccountName;
	}

	public void setAccountName(String accountName) {
		AccountName = accountName;
	}

	public String getLibraryID() {
		return LibraryID;
	}

	public void setLibraryID(String libraryID) {
		LibraryID = libraryID;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public boolean isIsAdmin() {
		return IsAdmin;
	}

	public void setIsAdmin(boolean isAdmin) {
		IsAdmin = isAdmin;
	}

	public Date getDJoined() {
		return DJoined;
	}

	public void setDJoined(Date dJoined) {
		DJoined = dJoined;
	}

	public Date getDExpired() {
		return DExpired;
	}

	public void setDExpired(Date dExpired) {
		DExpired = dExpired;
	}

	public int getPoints() {
		return Points;
	}

	public void setPoints(int points) {
		Points = points;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "Account [AccountNo=" + AccountNo + ", AccountName=" + AccountName + ", LibraryID=" + LibraryID
				+ ", Password=" + Password + ", IsAdmin=" + IsAdmin + ", DJoined=" + DJoined + ", DExpired=" + DExpired
				+ ", Points=" + Points + ", Status=" + Status + "]";
	}
}
