package entity;

import java.util.Date;

public class BookDetail {
	private int BookNo;
	private String Title;
	private String Author;
	private String Publisher;
	private Date YPublished;
	private String ISBN;
	private int Pages;
	private int ShelfNo;
	private String Description;
	private boolean Status;
		
	public BookDetail() {}

	

	public BookDetail(int bookNo, String title, String author, String publisher, Date yPublished, String iSBN,
			int pages, int shelfNo, String description, boolean status) {
		BookNo = bookNo;
		Title = title;
		Author = author;
		Publisher = publisher;
		YPublished = yPublished;
		ISBN = iSBN;
		Pages = pages;
		ShelfNo = shelfNo;
		Description = description;
		Status = status;
	}

	public int getBookNo() {
		return BookNo;
	}

	public void setBookNo(int bookNo) {
		BookNo = bookNo;
	}

	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		Title = title;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public String getPublisher() {
		return Publisher;
	}

	public void setPublisher(String publisher) {
		Publisher = publisher;
	}

	public Date getYPublished() {
		return YPublished;
	}

	public void setYPublished(Date yPublished) {
		YPublished = yPublished;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public int getShelfNo() {
		return ShelfNo;
	}

	public void setShelfNo(int shelfNo) {
		ShelfNo = shelfNo;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	public int getPages() {
		return Pages;
	}



	public void setPages(int pages) {
		Pages = pages;
	}



	@Override
	public String toString() {
		return "BookDetail [BookNo=" + BookNo + ", Title=" + Title + ", Author=" + Author + ", Publisher=" + Publisher
				+ ", YPublished=" + YPublished + ", ISBN=" + ISBN + ", Pages=" + Pages + ", ShelfNo=" + ShelfNo
				+ ", Description=" + Description + ", Status=" + Status + "]";
	}
}
