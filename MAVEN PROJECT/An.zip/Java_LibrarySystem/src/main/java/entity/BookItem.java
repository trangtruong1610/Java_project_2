package entity;

public class BookItem {
	private int ItemNo;
	private int BookNo;
	private String BookID;
	private boolean Status;
	
	public BookItem() {}

	public BookItem(int itemNo, int bookNo, String bookID, boolean status) {
		ItemNo = itemNo;
		BookNo = bookNo;
		BookID = bookID;
		Status = status;
	}

	public int getItemNo() {
		return ItemNo;
	}

	public void setItemNo(int itemNo) {
		ItemNo = itemNo;
	}

	public int getBookNo() {
		return BookNo;
	}

	public void setBookNo(int bookNo) {
		BookNo = bookNo;
	}

	public String getBookID() {
		return BookID;
	}

	public void setBookID(String bookID) {
		BookID = bookID;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "BookItem [ItemNo=" + ItemNo + ", BookNo=" + BookNo + ", BookID=" + BookID + ", Status=" + Status + "]";
	}
}
