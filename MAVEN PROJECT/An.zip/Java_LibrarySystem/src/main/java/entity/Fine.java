package entity;

public class Fine {
	private int FineNo;
	private int LendNo;
	private int OverdueDate;
	private int FineAmt;
		
	public Fine() {}

	public Fine(int fineNo, int lendNo, int overdueDate, int fineAmt) {
		FineNo = fineNo;
		LendNo = lendNo;
		OverdueDate = overdueDate;
		FineAmt = fineAmt;
	}

	public int getFineNo() {
		return FineNo;
	}

	public void setFineNo(int fineNo) {
		FineNo = fineNo;
	}

	public int getLendNo() {
		return LendNo;
	}

	public void setLendNo(int lendNo) {
		LendNo = lendNo;
	}

	public int getOverdueDate() {
		return OverdueDate;
	}

	public void setOverdueDate(int overdueDate) {
		OverdueDate = overdueDate;
	}

	public int getFineAmt() {
		return FineAmt;
	}

	public void setFineAmt(int fineAmt) {
		FineAmt = fineAmt;
	}

	@Override
	public String toString() {
		return "Fine [FineNo=" + FineNo + ", LendNo=" + LendNo + ", OverdueDate=" + OverdueDate + ", FineAmt=" + FineAmt
				+ "]";
	}
}
