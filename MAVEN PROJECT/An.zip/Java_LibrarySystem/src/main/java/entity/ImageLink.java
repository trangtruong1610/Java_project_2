package entity;

import java.util.Arrays;

public class ImageLink {
	private int ImgNo;
	private byte[] ImgLink;
	private int BookNo;
	private boolean IsCover;
	private boolean Status;
	
	public ImageLink() {}

	public ImageLink(int imgNo, byte[] imgLink, int bookNo, boolean isCover, boolean status) {
		ImgNo = imgNo;
		ImgLink = imgLink;
		BookNo = bookNo;
		IsCover = isCover;
		Status = status;
	}

	public int getImgNo() {
		return ImgNo;
	}

	public void setImgNo(int imgNo) {
		ImgNo = imgNo;
	}

	public byte[] getImgLink() {
		return ImgLink;
	}

	public void setImgLink(byte[] imgLink) {
		ImgLink = imgLink;
	}

	public int getBookNo() {
		return BookNo;
	}

	public void setBookNo(int bookNo) {
		BookNo = bookNo;
	}

	public boolean isIsCover() {
		return IsCover;
	}

	public void setIsCover(boolean isCover) {
		IsCover = isCover;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "ImageLink [ImgNo=" + ImgNo + ", ImgLink=" + Arrays.toString(ImgLink) + ", BookNo=" + BookNo
				+ ", IsCover=" + IsCover + ", Status=" + Status + "]";
	}
}
