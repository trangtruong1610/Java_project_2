package entity;

import java.util.Date;

public class LendingHistory {
	private int LendNo;
	private int ReserveNo;
	private int AccountNo;
	private int ItemNo;
	private Date DIssued;
	private Date DReturned;
	private boolean Status;
	
	public LendingHistory() {}

	public LendingHistory(int lendNo, int reserveNo, int accountNo, int itemNo, Date dIssued, Date dReturned,
			boolean status) {
		LendNo = lendNo;
		ReserveNo = reserveNo;
		AccountNo = accountNo;
		ItemNo = itemNo;
		DIssued = dIssued;
		DReturned = dReturned;
		Status = status;
	}

	
	public int getLendNo() {
		return LendNo;
	}

	public void setLendNo(int lendNo) {
		LendNo = lendNo;
	}

	public int getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}

	public int getItemNo() {
		return ItemNo;
	}

	public void setItemNo(int itemNo) {
		ItemNo = itemNo;
	}

	public Date getDIssued() {
		return DIssued;
	}

	public void setDIssued(Date dIssued) {
		DIssued = dIssued;
	}

	public Date getDReturned() {
		return DReturned;
	}

	public void setDReturned(Date dReturned) {
		DReturned = dReturned;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "LendingHistory [LendNo=" + LendNo + ", AccountNo=" + AccountNo + ", ItemNo=" + ItemNo + ", DIssued="
				+ DIssued + ", DReturned=" + DReturned + ", Status=" + Status + "]";
	}

	/**
	 * @return the reserveNo
	 */
	public int getReserveNo() {
		return ReserveNo;
	}

	/**
	 * @param reserveNo the reserveNo to set
	 */
	public void setReserveNo(int reserveNo) {
		ReserveNo = reserveNo;
	}
}
