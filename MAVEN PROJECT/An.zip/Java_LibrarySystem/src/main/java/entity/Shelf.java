package entity;

public class Shelf {
	private int ShelfNo;
	private String ShelfName;
	private boolean Status;
	
	public Shelf() {}
	
	public Shelf(int shelfNo, String shelfName, boolean status) {
		ShelfNo = shelfNo;
		ShelfName = shelfName;
		Status = status;
	}

	public int getShelfNo() {
		return ShelfNo;
	}

	public void setShelfNo(int shelfNo) {
		ShelfNo = shelfNo;
	}

	public String getShelfName() {
		return ShelfName;
	}

	public void setShelfName(String shelfName) {
		ShelfName = shelfName;
	}

	public boolean isStatus() {
		return Status;
	}

	public void setStatus(boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "Shelf [ShelfNo=" + ShelfNo + ", ShelfName=" + ShelfName + ", Status=" + Status + "]";
	}
}
