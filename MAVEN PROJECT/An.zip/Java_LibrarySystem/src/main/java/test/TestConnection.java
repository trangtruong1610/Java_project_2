package test;

import java.sql.DriverManager;
import java.sql.SQLException;

import common.ConnectToProperties;

public class TestConnection {
	public static void main(String[] args) {
		
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
		) {
			System.out.println("Successfully Connected!");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}
