package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import com.toedter.calendar.JDateChooser;

import common.ConnectToProperties;
import entity.Account;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPasswordField;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class Account_AccountManagement extends JFrame {

	private JPanel contentPane;
	private JFrame frame;
	private JTextField username;
	private JTextField id;
	private JTextField point;
	private JTable tableAccount;
	private boolean isAdmin = false;
	private JTextField no;
	private JTextField searchdata;
	private JPasswordField password;
	private JLabel id_validation;
	private JLabel user_validation;
	private JLabel pass_validation;
	private String txtName, txtId, txtPass, txtNo;
	private String joiningDate;
	private String expiredDate;
	private java.sql.Date joindate;
	private java.sql.Date expiredate;
	private static String accountName;
	
	public ArrayList<Account> accountsList(){
		ArrayList<Account> accountsList = new ArrayList<>();
		try (
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
		) {
			String query = "SELECT * FROM Account";
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			Account account;
			
			while(rs.next()) {
				account = new Account(rs.getInt("AccountNo"), rs.getString("AccountName"), rs.getString("LibraryID"), rs.getString("Password"), rs.getBoolean("IsAdmin"), rs.getDate("DJoined"),rs.getDate("DExpired"),rs.getInt("Points"),rs.getBoolean("Status"));
				accountsList.add(account);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return accountsList;
	}
	
	public void show_account() {
		ArrayList<Account> list = accountsList();
		DefaultTableModel model = (DefaultTableModel)tableAccount.getModel();
				
		for(var acc : list) {
			var status = "";
			if(acc.isStatus() == false) {
				status = "Deactive";
			} else {
				status = "Active";
			}
				
			model.addRow(new Object[] {
					acc.getAccountNo(),
					acc.getAccountName(),
					acc.getLibraryID(),
					acc.getDJoined(),
					acc.getDExpired(),
					acc.getPoints(),
					status
			});
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		accountName = args[0];
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Account_AccountManagement frame = new Account_AccountManagement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Account_AccountManagement() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 180, 1200, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(220, 220, 220));
		panel.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(128, 128, 128)));
		panel.setBounds(0, 0, 1188, 730);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(128, 128, 128)));
		panel_1.setBackground(new Color(220, 220, 220));
		panel_1.setBounds(10, 49, 1165, 31);
		panel.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("LIBRARY SYSTEM");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 20));
		panel_1.add(lblNewLabel);
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(128, 128, 128)));
		panel_1_1.setBackground(new Color(220, 220, 220));
		panel_1_1.setBounds(10, 80, 250, 565);
		panel.add(panel_1_1);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(10, 105, 100, 15);
		panel_1_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Library ID");
		lblNewLabel_1_1.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1.setBounds(10, 170, 100, 15);
		panel_1_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Password");
		lblNewLabel_1_2.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_2.setBounds(10, 235, 100, 15);
		panel_1_1.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Joining Date");
		lblNewLabel_1_3.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_3.setBounds(10, 304, 100, 15);
		panel_1_1.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_5 = new JLabel("Point");
		lblNewLabel_1_5.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_5.setBounds(10, 435, 100, 15);
		panel_1_1.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Status");
		lblNewLabel_1_6.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_6.setBounds(10, 505, 100, 15);
		panel_1_1.add(lblNewLabel_1_6);
		
		username = new JTextField();
		username.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				try (
						Connection connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
					String queryAcc = "SELECT * From Account where AccountName=?";
					PreparedStatement pstAcc = connection.prepareStatement(queryAcc);
					pstAcc.setString(1, username.getText());
					ResultSet rsAcc = pstAcc.executeQuery();
					
					if(rsAcc.next()) {
						user_validation.setText("Username already exists");
						user_validation.setForeground(Color.cyan);
						} else {
							String USER_PATTERN = "Student\\d{3,10}";
							Pattern patternUser = Pattern.compile(USER_PATTERN);
							Matcher matcherUser = patternUser.matcher(username.getText()); 
							if(matcherUser.matches()) {
								user_validation.setText("");
								txtName = username.getText();
							}else {
								user_validation.setForeground(Color.red);
								user_validation.setText("Account Name must start with Student*****");
							}
						}
					} catch (SQLException err) {
					System.out.println(err.getMessage());
				}
			}
		});
		username.setBounds(10, 120, 215, 20);
		panel_1_1.add(username);
		username.setColumns(10);
		
		id = new JTextField();
		id.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				try (
						var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
					String queryDB = "SELECT * From Account where LibraryID=?";
					PreparedStatement pstDB = connection.prepareStatement(queryDB);
					pstDB.setString(1, id.getText());
					ResultSet rs = pstDB.executeQuery();
					
					if(rs.next()) {
						id_validation.setText("Library ID already exists");
						id_validation.setForeground(new Color(39,59,47));
						} else {
							String ID_PATTERN = "\\d{6}[-][A-Z]\\d{4}";
							Pattern pattern = Pattern.compile(ID_PATTERN);
							Matcher matcher = pattern.matcher(id.getText()); 
							if(matcher.matches()) {
								id_validation.setText("");
								txtId = id.getText();
							}else {
								id_validation.setForeground(Color.red);
								id_validation.setText("Library ID must start with 000000-A0000");
							}
						}
					} catch (SQLException err) {
					System.out.println(err.getMessage());
				}
			}
		});
		id.setColumns(10);
		id.setBounds(10, 185, 215, 20);
		panel_1_1.add(id);
		
		point = new JTextField();
		point.setText("100");
		point.setColumns(10);
		point.setBounds(10, 450, 215, 20);
		panel_1_1.add(point);
		
		JDateChooser joiningDateChooser = new JDateChooser();
		joiningDateChooser.setDateFormatString("yyyy-MM-dd");
		joiningDateChooser.setDate(new Date());
		joiningDateChooser.setBounds(10, 320, 215, 20);
		panel_1_1.add(joiningDateChooser);
		joiningDate = joiningDateChooser.getDate().toString();
		try {
			joindate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(joiningDate).getTime());
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		JDateChooser expiryDateChooser = new JDateChooser();
		expiryDateChooser.setDateFormatString("yyyy-MM-dd");
		var date = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(date);
		now.add(Calendar.YEAR, 4);
		var expireDate = now.getTime();
		expiryDateChooser.setDate(expireDate);
		expiredDate = joiningDateChooser.getDate().toString();
		try {
			expiredate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(expiredDate).getTime());
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		expiryDateChooser.setBounds(10, 385, 215, 20);
		panel_1_1.add(expiryDateChooser);
		
		JComboBox status = new JComboBox();
		status.setModel(new DefaultComboBoxModel(new String[] {"Active", "Deactive"}));
		status.setBounds(10, 520, 215, 22);
		panel_1_1.add(status);
		
		JLabel lblSearch = new JLabel("");
		lblSearch.setForeground(new Color(255, 255, 255));
		lblSearch.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 15));
		lblSearch.setIcon(new ImageIcon(setImgIcon("search.png")));
		lblSearch.setBounds(205, 11, 35, 30);
		panel_1_1.add(lblSearch);
		
		no = new JTextField();
		no.setEnabled(false);
		no.setColumns(10);
		no.setBounds(10, 55, 215, 20);
		panel_1_1.add(no);
		
		searchdata = new JTextField();
		searchdata.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try (
						Connection connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
					String sql = "Select * from Account where LibraryID = ?";
					PreparedStatement pst = connection.prepareStatement(sql);
					pst.setString(1, searchdata.getText());
					ResultSet rs = pst.executeQuery();
					if(rs.next()) {
						String setNo = String.valueOf(rs.getInt("AccountNo"));
						no.setText(setNo);
						
						String setUsername = rs.getString("AccountName");
						username.setText(setUsername);
						username.setEnabled(false);
						
						String setId = rs.getString("LibraryID");
						id.setText(setId);
						id.setEnabled(false);
						
						String setPassword = rs.getString("Password");
						password.setText(setPassword);
						password.setEnabled(false);
						
						joiningDateChooser.setDate(rs.getDate("DJoined"));
						expiryDateChooser.setDate(rs.getDate("DExpired"));
						
						String setPoint = rs.getString("Points");
						point.setText(setPoint);
						
						boolean _status = rs.getBoolean("Status");
						status.setSelectedIndex(1);
						if(_status) {
							status.setSelectedIndex(0);
						}
					}
				} catch (SQLException error) {
					System.out.println(error.getMessage());
				}
			}
		});
		searchdata.setColumns(10);
		searchdata.setBounds(10, 15, 195, 20);
		panel_1_1.add(searchdata);
		
		JLabel lblNewLabel_1_7 = new JLabel("No");
		lblNewLabel_1_7.setForeground(Color.WHITE);
		lblNewLabel_1_7.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_7.setBounds(10, 37, 100, 15);
		panel_1_1.add(lblNewLabel_1_7);
		
		password = new JPasswordField();
		password.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				if(password.getText().length() < 8 || password.getText().length() > 20) {
					pass_validation.setText("Password must be 8 to 20 character");
				}else {
					pass_validation.setText("");
					txtPass = password.getText();
				}
			}
		});
		password.setBounds(10, 250, 215, 20);
		panel_1_1.add(password);
		
		JLabel lblNewLabel_1_4 = new JLabel("Expiry Date");
		lblNewLabel_1_4.setBounds(10, 370, 215, 15);
		panel_1_1.add(lblNewLabel_1_4);
		lblNewLabel_1_4.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 12));
		lblNewLabel_1_4.setForeground(new Color(255, 255, 255));
		
		user_validation = new JLabel("");
		user_validation.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 9));
		user_validation.setForeground(new Color(255, 0, 0));
		user_validation.setBounds(10, 145, 215, 14);
		panel_1_1.add(user_validation);
		
		id_validation = new JLabel("");
		id_validation.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 9));
		id_validation.setForeground(new Color(255, 0, 0));
		id_validation.setBounds(10, 210, 215, 14);
		panel_1_1.add(id_validation);
		
		pass_validation = new JLabel("");
		pass_validation.setFont(new Font("Segoe UI SemiBold", Font.BOLD, 9));
		pass_validation.setForeground(new Color(255, 0, 0));
		pass_validation.setBounds(10, 275, 215, 14);
		panel_1_1.add(pass_validation);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(128, 128, 128)));
		panel_1_1_1.setBackground(new Color(220, 220, 220));
		panel_1_1_1.setBounds(259, 80, 916, 565);
		panel.add(panel_1_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 896, 543);
		panel_1_1_1.add(scrollPane);
		
		tableAccount = new JTable();
		tableAccount.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				user_validation.setText("");
				id_validation.setText("");
				pass_validation.setText("");
				
				int index = tableAccount.getSelectedRow();
				no.setText(tableAccount.getValueAt(index, 0).toString());
				no.setEnabled(false);
				username.setText(tableAccount.getValueAt(index, 1).toString());
				username.setEnabled(false);
				id.setText(tableAccount.getValueAt(index, 2).toString());
				id.setEnabled(false);
								
				try {
					int srow = tableAccount.getSelectedRow();
					var joiningDate = tableAccount.getValueAt(srow, 3).toString();
					java.sql.Date joindate = null;
					try {
						joindate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(joiningDate).getTime());
					} catch (Exception e1) {
						e1.getMessage();
					}
					joiningDateChooser.setDate(joindate);
					
					var expiredDate = tableAccount.getValueAt(srow, 4).toString();
					java.sql.Date expiredate = null;
					try {
						expiredate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(expiredDate).getTime());
					} catch (Exception e1) {
						e1.getMessage();
					}
					expiryDateChooser.setDate(expiredate);
				}catch(Exception err) {
					JOptionPane.showMessageDialog(null, err);
				}
				
				point.setText(tableAccount.getValueAt(index, 5).toString());
				
				String status_ = tableAccount.getValueAt(index, 6).toString();
				switch(status_) {
				case "Active":
					status.setSelectedIndex(0);
					break;
				case "Deactive":
					status.setSelectedIndex(1);
					break;
				}
				
				username.setText(tableAccount.getValueAt(index, 1).toString());
				username.setText(tableAccount.getValueAt(index, 1).toString());
			}
		});
		tableAccount.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"No", "Username", "Library ID", "Joining Date", "Expiry Date", "Point", "Status"
			}
		));
		scrollPane.setViewportView(tableAccount);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setBorder(new MatteBorder(2, 2, 2, 2, (Color) new Color(128, 128, 128)));
		panel_1_2.setBackground(new Color(220, 220, 220));
		panel_1_2.setBounds(10, 650, 1165, 50);
		panel.add(panel_1_2);
		
		JButton btnCreate = new JButton("CREATE");
		btnCreate.setBackground(new Color(0, 0, 255));
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (
						var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
					if (txtName != null && txtId !=null && txtPass != null) {
						String query = "insert into Account(AccountName, LibraryID, Password, IsAdmin, DJoined, DExpired, Points, Status)values(?,?,?,?,?,?,?,?)";
						PreparedStatement pst = connection.prepareStatement(query);
						pst.setString(1, username.getText());
						pst.setString(2, id.getText());
						pst.setString(3, password.getText());
						pst.setBoolean(4, isAdmin);
						
						pst.setDate(5, joindate);
						pst.setDate(6, expiredate);
						
						pst.setString(7, point.getText());
						
						String _status = status.getSelectedItem().toString();
						boolean status_ = true;
						if(_status.equalsIgnoreCase("deactive")) {
							status_ = false;
						}
						pst.setBoolean(8, status_);
						
						pst.executeUpdate();
						
						DefaultTableModel model = (DefaultTableModel)tableAccount.getModel();
						model.setRowCount(0);
						show_account();
						JOptionPane.showMessageDialog(null, "Account created successfully!");
						
						username.setText("");
						password.setText("");
						id.setText("");
						joiningDateChooser.setDate(new Date());
						var date = new Date();
						Calendar now = Calendar.getInstance();
						now.setTime(date);
						now.add(Calendar.YEAR, 4);
						var expireDate = now.getTime();
						expiryDateChooser.setDate(expireDate);
						point.setText("");
						status.setSelectedIndex(0);
					}else {
						JOptionPane.showMessageDialog(null, "Please fill in the required fields");
					}
					
				} catch (SQLException err) {
					System.out.println(err.getMessage());
				}
				
			}
		});
		btnCreate.setForeground(new Color(255, 255, 255));
		
		btnCreate.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnCreate.setBounds(69, 13, 150, 25);
		panel_1_2.add(btnCreate);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.setBackground(new Color(0, 128, 0));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (
						var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				) {
						String value = no.getText();
						txtName = username.getText();
						String query = "UPDATE Account SET Password=?, DExpired=?, Points=?, Status=? where AccountNo =" + value;
						PreparedStatement pst = connection.prepareStatement(query);
						
						pst.setString(1, password.getText());
						
						pst.setDate(2, expiredate);
						
						pst.setString(3, point.getText());
						
						String _status = status.getSelectedItem().toString();
						boolean status_ = false;
						if(_status.equalsIgnoreCase("active")) {
							status_ = true;
						}
						pst.setBoolean(4, status_);

						pst.executeUpdate();
						
						DefaultTableModel model = (DefaultTableModel)tableAccount.getModel();
						model.setRowCount(0);
						show_account();
						JOptionPane.showInternalMessageDialog(null, txtName + " Updated Successfully!");
						
						username.setText("");
						username.setEnabled(true);
						user_validation.setText("");
						password.setText("");
						password.setEnabled(true);
						pass_validation.setText("");
						id.setText("");
						id.setEnabled(true);
						id_validation.setText("");
						expiryDateChooser.setDate(java.sql.Date.valueOf(java.time.LocalDate.now())); 
						joiningDateChooser.setDate(java.sql.Date.valueOf(java.time.LocalDate.now())); 
						point.setText("");
						status.setSelectedIndex(0);
					
				} catch (SQLException error) {
					System.out.println(error.getMessage());
				}
			}
		});
		btnUpdate.setForeground(new Color(255, 255, 255));
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnUpdate.setBounds(288, 13, 150, 25);
		panel_1_2.add(btnUpdate);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.setBackground(new Color(255, 165, 0));
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				username.setText("");
				username.setEnabled(true);
				user_validation.setText("");
				password.setText("");
				password.setEnabled(true);
				pass_validation.setText("");
				id.setText("");
				id.setEnabled(true);
				id_validation.setText("");
				
				joiningDateChooser.setDate(new Date());
				
				var date = new Date();
				Calendar now = Calendar.getInstance();
				now.setTime(date);
				now.add(Calendar.YEAR, 4);
				var expireDate = now.getTime();
				
				expiryDateChooser.setDate(expireDate);
				
				 
				point.setText("");
				status.setSelectedIndex(0);
			}
		});
		btnClear.setForeground(new Color(255, 255, 255));
		btnClear.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnClear.setBounds(726, 13, 150, 25);
		panel_1_2.add(btnClear);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.setBackground(new Color(255, 0, 0));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int opt = JOptionPane.showConfirmDialog(null,"Are You sure to Delete", "Delete", JOptionPane.YES_NO_OPTION);
				
				if(opt==0) {
					try (
							var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
					) {
						txtName = username.getText();
						int row = tableAccount.getSelectedRow();
						String value = (tableAccount.getModel().getValueAt(row, 0).toString());
						String query = "DELETE FROM Account where AccountNo=" + value;
						PreparedStatement pst = connection.prepareStatement(query);
						pst.executeUpdate();
						
						DefaultTableModel model = (DefaultTableModel)tableAccount.getModel();
						model.setRowCount(0);
						
						show_account();
						JOptionPane.showMessageDialog(null, txtName + " Deleted Successfully!");
						
						username.setText("");
						password.setText("");
						id.setText("");
						joiningDateChooser.setCalendar(null);
						expiryDateChooser.setCalendar(null);
						point.setText("");
						status.setSelectedIndex(0);
						
					} catch (SQLException error) {
						System.out.println(error.getMessage());
					}
				}
			}
		});
		btnDelete.setForeground(Color.WHITE);
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDelete.setBounds(507, 13, 150, 25);
		panel_1_2.add(btnDelete);
		
		JButton btnResetPassword = new JButton("RESET PASSWORD");
		btnResetPassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnResetPasswordActionPerformed(e);
			}
		});
		btnResetPassword.setForeground(Color.WHITE);
		btnResetPassword.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnResetPassword.setBackground(new Color(64, 224, 208));
		btnResetPassword.setBounds(945, 13, 150, 25);
		panel_1_2.add(btnResetPassword);
		
		JButton btnClose = new JButton("Logout");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCloseActionPerformed(e);
			}
		});
		btnClose.setForeground(new Color(245, 245, 245));
		btnClose.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
		btnClose.setBackground(new Color(105, 105, 105));
		btnClose.setBounds(230, 13, 100, 25);
		panel.add(btnClose);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAccountActionPerformed(e);
			}
		});
		btnBack.setForeground(new Color(245, 245, 245));
		btnBack.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
		btnBack.setBackground(new Color(105, 105, 105));
		btnBack.setBounds(120, 13, 100, 25);
		panel.add(btnBack);
		
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHomeActionPerformed(e);
			}
		});
		btnHome.setForeground(new Color(245, 245, 245));
		btnHome.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
		btnHome.setBackground(new Color(105, 105, 105));
		btnHome.setBounds(10, 13, 100, 25);
		panel.add(btnHome);
		
		btnHome.setContentAreaFilled(true);
		btnBack.setContentAreaFilled(true);
		btnClose.setContentAreaFilled(true);
		
		show_account();
		
	}
	
	private Image setImgIcon(String img_Name) {
		
		var path = "image/icons/" + img_Name;
		
		Image img = new ImageIcon(path).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
		
		return img;
	}
	protected void btnAccountActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		Home_AdminHome.main(arr);
	}
	protected void btnCloseActionPerformed(ActionEvent e) {
		dispose();
		Home_LibraryHome.main(null);
		setVisible(false);
	}
	protected void btnHomeActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		Home_LibraryHome.main(arr);
	}
	protected void btnResetPasswordActionPerformed(ActionEvent e) {
		var result = tableAccount.getSelectionModel().isSelectionEmpty();
		if(!result) {
			try (
					var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
			) {
				var accountNo = tableAccount.getValueAt(tableAccount.getSelectedRow(), 0);
				String query = "UDPATE Account SET Password = 'Pass@123' WHERE AccountNo =" + accountNo;
				PreparedStatement pst = connection.prepareStatement(query);
				pst.executeUpdate();
				
				JOptionPane.showMessageDialog(null, "Password is successfully reset.");
			} catch (SQLException error) {
				System.out.println(error.getMessage());
			}
		} else {
			JOptionPane.showMessageDialog(null, "Please select an account to reset password.");
		}
	}
}

