package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import org.apache.commons.io.FilenameUtils;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.LayoutManager;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import com.toedter.calendar.JDateChooser;

import common.Convertor;
import dao.DAOProduct;

import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.imageio.ImageIO;
import javax.swing.AbstractListModel;
import javax.swing.JToggleButton;
import javax.swing.JToolTip;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import javax.swing.border.BevelBorder;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BoxLayout;
import javax.swing.JTextArea;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowEvent;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.CardLayout;

public class Add_NewBook extends JFrame {

	private JPanel contentPane;
	private JLabel lblTitle;
	private JTextField txtTitle;
	private JTextField txtAuthor;
	private JLabel lblAuthor;
	private JTextField txtPublisher;
	private JLabel lblPublisher;
	private JDateChooser dateChooser;
	private JLabel lblDatePublished;
	private JLabel lblBookGenres;
	private JLabel lblShelf;
	private JComboBox comboBox;
	private JLabel lblBookCover;
	private JTextField txtBookCover;
	private JButton btnCover;
	private JLabel lblBookImages;
	private JTextField txtBookImg;
	private JButton btnImage;
	private JButton btnAddBook;
	private JButton btnCancel;
	private JLabel lblISBN;
	private JTextField txtISBN;
	private JPanel panel;
	private JLabel lblImg;
	private JLabel lblDescription;
	private JTextArea txtDescription;
	private JLabel lblPage;
	private JTextField txtPage;
	private JButton btnSelect;
	private JTextField txtBookGenre;
	private static String bookGenre;
	private JPanel panel_1;
	private JPanel panel_2;
	private JScrollPane scrollPane;
	private JPanel panel_3;
	private JButton btnGenreOK;
	private JButton btnGenreCancel;
	private JLabel lblNewLabel;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_NewBook frame = new Add_NewBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_NewBook() {
		setResizable(false);
		setTitle("Add New Book");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 680);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
		
		contentPane = new JPanel();
		contentPane.setForeground(new Color(245, 245, 245));
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));


		panel_1 = new JPanel();
		panel_1.setBorder(null);
		panel_1.setBackground(new Color(105, 105, 105));
		contentPane.add(panel_1, "name_368456477629100");
		panel_1.setLayout(null);
		
		lblTitle = new JLabel("Book Title");
		lblTitle.setBounds(20, 36, 81, 23);
		panel_1.add(lblTitle);
		lblTitle.setForeground(new Color(255, 255, 255));
		lblTitle.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtTitle = new JTextField();
		txtTitle.setBounds(111, 34, 557, 27);
		panel_1.add(txtTitle);
		txtTitle.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtTitle.setColumns(10);
		
		lblAuthor = new JLabel("Author");
		lblAuthor.setBounds(20, 72, 81, 23);
		panel_1.add(lblAuthor);
		lblAuthor.setForeground(Color.WHITE);
		lblAuthor.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtAuthor = new JTextField();
		txtAuthor.setBounds(111, 72, 557, 27);
		panel_1.add(txtAuthor);
		txtAuthor.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtAuthor.setColumns(10);
		
		lblPublisher = new JLabel("Publisher");
		lblPublisher.setBounds(20, 112, 81, 23);
		panel_1.add(lblPublisher);
		lblPublisher.setForeground(Color.WHITE);
		lblPublisher.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtPublisher = new JTextField();
		txtPublisher.setBounds(111, 112, 557, 27);
		panel_1.add(txtPublisher);
		txtPublisher.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtPublisher.setColumns(10);
		
		lblDatePublished = new JLabel("Date Published");
		lblDatePublished.setBounds(20, 155, 81, 23);
		panel_1.add(lblDatePublished);
		lblDatePublished.setForeground(Color.WHITE);
		lblDatePublished.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(111, 153, 247, 27);
		panel_1.add(dateChooser);
		dateChooser.setDateFormatString("yyyy-MM-dd");
		dateChooser.setDate(new Date());
		
		txtPage = new JTextField();
		txtPage.setBounds(421, 153, 247, 27);
		panel_1.add(txtPage);
		txtPage.setColumns(10);
		
		lblPage = new JLabel("Pages");
		lblPage.setBounds(368, 155, 43, 23);
		panel_1.add(lblPage);
		lblPage.setForeground(Color.WHITE);
		lblPage.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		lblISBN = new JLabel("ISBN");
		lblISBN.setBounds(20, 191, 81, 23);
		panel_1.add(lblISBN);
		lblISBN.setForeground(Color.WHITE);
		lblISBN.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtISBN = new JTextField();
		txtISBN.setBounds(111, 191, 247, 27);
		panel_1.add(txtISBN);
		txtISBN.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtISBN.setColumns(10);
		
		lblShelf = new JLabel("Shelf");
		lblShelf.setBounds(368, 191, 43, 23);
		panel_1.add(lblShelf);
		lblShelf.setForeground(Color.WHITE);
		lblShelf.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		comboBox = new JComboBox();
		comboBox.setBounds(421, 189, 247, 27);
		panel_1.add(comboBox);
		comboBox.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		comboBox.setBackground(new Color(169, 169, 169));
		setComboBoxShelf(comboBox);
		
		lblDescription = new JLabel("Description");
		lblDescription.setBounds(20, 271, 81, 23);
		panel_1.add(lblDescription);
		lblDescription.setForeground(Color.WHITE);
		lblDescription.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtDescription = new JTextArea();
		txtDescription.setBounds(111, 271, 557, 188);
		panel_1.add(txtDescription);
		txtDescription.setWrapStyleWord(true);
		txtDescription.setLineWrap(true);
		txtDescription.setBackground(new Color(245, 245, 245));
		txtDescription.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		
		lblBookGenres = new JLabel("Book Genres");
		lblBookGenres.setBounds(20, 231, 81, 23);
		panel_1.add(lblBookGenres);
		lblBookGenres.setForeground(Color.WHITE);
		lblBookGenres.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		btnSelect = new JButton("Select");
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSelectActionPerformed(e);
			}
		});
		btnSelect.setBounds(111, 232, 87, 23);
		panel_1.add(btnSelect);
		
		btnSelect.setBackground(Color.LIGHT_GRAY);
		
		txtBookGenre = new JTextField();
		txtBookGenre.setBounds(208, 233, 460, 27);
		panel_1.add(txtBookGenre);
		txtBookGenre.setText(bookGenre);
		txtBookGenre.setForeground(new Color(245, 245, 245));
		txtBookGenre.setFont(new Font("Segoe UI Semibold", Font.ITALIC, 12));
		txtBookGenre.setEditable(false);
		txtBookGenre.setColumns(10);
		txtBookGenre.setBorder(null);
		txtBookGenre.setBackground(SystemColor.controlDkShadow);
		
		txtBookCover = new JTextField();
		txtBookCover.setBounds(208, 470, 460, 27);
		panel_1.add(txtBookCover);
		txtBookCover.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtBookCover.setColumns(10);
		
		btnCover = new JButton("Choose File");
		btnCover.setBounds(111, 473, 87, 23);
		panel_1.add(btnCover);
		btnCover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCoverActionPerformed(e);
			}
		});
		btnCover.setBackground(new Color(192, 192, 192));
		
		lblBookCover = new JLabel("Book Cover");
		lblBookCover.setBounds(20, 472, 81, 23);
		panel_1.add(lblBookCover);
		lblBookCover.setForeground(Color.WHITE);
		lblBookCover.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		lblBookImages = new JLabel("Book Images");
		lblBookImages.setBounds(20, 510, 81, 23);
		panel_1.add(lblBookImages);
		lblBookImages.setForeground(Color.WHITE);
		lblBookImages.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		
		txtBookImg = new JTextField() {
			@Override
			public JToolTip createToolTip() {
				return createCustomToolTip();
			}
		};
		txtBookImg.setBounds(208, 508, 460, 27);
		panel_1.add(txtBookImg);
		txtBookImg.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				textFieldMouseEntered(e);
			}
		});
		txtBookImg.setToolTipText("");
		txtBookImg.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		txtBookImg.setColumns(10);
		
		btnImage = new JButton("Choose File");
		btnImage.setBounds(111, 511, 87, 23);
		panel_1.add(btnImage);
		btnImage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnImageActionPerformed(e);
			}
		});
		btnImage.setBackground(new Color(192, 192, 192));
		
		btnAddBook = new JButton("Add Book");
		btnAddBook.setBounds(20, 572, 77, 23);
		panel_1.add(btnAddBook);
		btnAddBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAddBookActionPerformed(e);
			}
		});
		btnAddBook.setForeground(new Color(245, 245, 245));
		btnAddBook.setFont(new Font("Segoe UI Semibold", Font.BOLD, 11));
		btnAddBook.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnAddBook.setBackground(new Color(0, 206, 209));
		
		btnAddBook.setContentAreaFilled(true);
		
		btnCancel = new JButton("Cancel");
		btnCancel.setBounds(111, 572, 77, 23);
		panel_1.add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancelActionPerformed(e);
			}
		});
		btnCancel.setForeground(new Color(245, 245, 245));
		btnCancel.setFont(new Font("Segoe UI Semibold", Font.BOLD, 11));
		btnCancel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCancel.setBackground(new Color(0, 206, 209));
		btnCancel.setContentAreaFilled(true);
		
		panel = new JPanel();
		panel.setBounds(689, 34, 298, 376);
		panel_1.add(panel);
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(new Color(245, 245, 245));
		panel.setLayout(null);
		
		lblImg = new JLabel("");
		lblImg.setBounds(3, 2, 290, 370);
		panel.add(lblImg);

		panel_2 = new JPanel();
		panel_2.setBackground(new Color(105, 105, 105));
		contentPane.add(panel_2, "name_368869850895200");
		panel_2.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBackground(new Color(245, 245, 245));
		scrollPane.setBounds(40, 82, 924, 423);
		panel_2.add(scrollPane);
		
		panel_3 = new JPanel();
		panel_3.setBorder(new EmptyBorder(50, 50, 50, 50));
		panel_3.setBackground(new Color(245, 245, 245));
		scrollPane.setViewportView(panel_3);
		panel_3.setLayout(new GridLayout(0, 4, 20, 20));
		
		btnGenreOK = new JButton("OK");
		btnGenreOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnGenreOKActionPerformed(e);
			}
		});
		btnGenreOK.setForeground(new Color(245, 245, 245));
		btnGenreOK.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
		btnGenreOK.setBackground(new Color(255, 140, 0));
		btnGenreOK.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnGenreOK.setBounds(40, 540, 89, 30);
		panel_2.add(btnGenreOK);
		
		btnGenreCancel = new JButton("Cancel");
		btnGenreCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnGenreCancelActionPerformed(e);
			}
		});
		btnGenreCancel.setForeground(new Color(245, 245, 245));
		btnGenreCancel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
		btnGenreCancel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnGenreCancel.setBackground(new Color(255, 140, 0));
		btnGenreCancel.setBounds(175, 540, 89, 30);
		panel_2.add(btnGenreCancel);
		
		lblNewLabel = new JLabel("Choose Book Genre");
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setForeground(new Color(245, 245, 245));
		lblNewLabel.setFont(new Font("Elephant", Font.BOLD, 35));
		lblNewLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(40, 36, 922, 35);
		panel_2.add(lblNewLabel);
		chooseBookGenres(panel_3);
	}
	
	
	private void getCoverLink() {
		
		var jfile = new JFileChooser();
//		jfile.setCurrentDirectory(new File(System.getProperty("user.home")));
		
		jfile.setCurrentDirectory(new File("D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image"));
		FileFilter png = new FileTypeFilter(".png","Portable Network Graphics");
		FileFilter jpg = new FileTypeFilter(".jpg", "Joint Photographic Experts Group");
		FileFilter jpeg = new FileTypeFilter(".jpeg", "Joint Photographic Experts Group");
		FileFilter tiff = new FileTypeFilter(".tiff", "Tagged Image File Format");
		jfile.setFileFilter(png);
		jfile.setFileFilter(jpg);
		jfile.setFileFilter(jpeg);
		jfile.setFileFilter(tiff);
		
		jfile.setAcceptAllFileFilterUsed(false);
		
		jfile.setDialogTitle("Choose Book Cover");
		int result = jfile.showOpenDialog(this);
		if(result == JFileChooser.APPROVE_OPTION) {
			var convert = new Convertor();
			var path = jfile.getSelectedFile().getAbsolutePath();
			var img = convert.loadImg(path);
			var newH = 370;
			var newW = convert.resizeImageWRatioH(img, newH);
			var cover = new ImageIcon(img).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
			lblImg.setIcon(new ImageIcon(cover));
			lblImg.setHorizontalAlignment(SwingConstants.CENTER);
			lblImg.setVerticalAlignment(SwingConstants.CENTER);
			
			txtBookCover.setText(path);
		}
	}
	
	private void multipleImgs() {
		var txt = "";
	
		var jfile = new JFileChooser();
//		jfile.setCurrentDirectory(new File(System.getProperty("user.home")));
		
		jfile.setCurrentDirectory(new File("D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image"));
		
		FileFilter png = new FileTypeFilter(".png","Portable Network Graphics");
		FileFilter jpg = new FileTypeFilter(".jpg", "Joint Photographic Experts Group");
		FileFilter jpeg = new FileTypeFilter(".jpeg", "Joint Photographic Experts Group");
		FileFilter tiff = new FileTypeFilter(".tiff", "Tagged Image File Format");
		jfile.setFileFilter(png);
		jfile.setFileFilter(jpg);
		jfile.setFileFilter(jpeg);
		jfile.setFileFilter(tiff);
		
		jfile.setAcceptAllFileFilterUsed(false);
		jfile.setMultiSelectionEnabled(true);
		
		jfile.setDialogTitle("Choose Book Images");
		int result = jfile.showOpenDialog(this);
		
		if(result == JFileChooser.APPROVE_OPTION) {
			File[] files = jfile.getSelectedFiles();
			for(var file : files) {
				var file_path = file.getAbsolutePath();
				txt += file_path + ";";
			}
			
			txtBookImg.setText(txt);
		}
	}
			
	public class FileTypeFilter extends FileFilter {
	    private String extension;
	    private String description;
	 
	    public FileTypeFilter(String extension, String description) {
	        this.extension = extension;
	        this.description = description;
	    }
	 
	    public boolean accept(File file) {
	        if (file.isDirectory()) {
	            return true;
	        }
	        return file.getName().endsWith(extension);
	    }
	 
	    public String getDescription() {
	        return description + String.format(" (*%s)", extension);
	    }
	}

	protected void btnAddBookActionPerformed(ActionEvent e) {
		var title = txtTitle.getText();
		var author = txtAuthor.getText();
		var publisher = txtPublisher.getText();
		var isbn = txtISBN.getText();
		var dPublished = dateChooser.getDate().toString();
		var shelfName  = comboBox.getSelectedItem().toString();
		var shelfNo = DAOProduct.getShelfNo(shelfName); 
		var description = txtDescription.getText();
		var page = Integer.parseInt(txtPage.getText());
		
		String bookCover = null;
		if(txtBookCover.getText().equals("") || txtBookCover.getText() == null) {
			bookCover = "D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image\\books\\0_No-Image-Available.png";
		} else {
			bookCover = txtBookCover.getText();
		}
		
		String bookImg = null;
		if(txtBookImg.getText().equalsIgnoreCase("") || txtBookImg.getText() == null) {
			bookImg =  "D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image\\books\\0_No-Image-Available.png";
		} else {
			bookImg = txtBookImg.getText();
		}
		
		var bookCategory = txtBookGenre.getText();
		
		DAOProduct.addNewBook(title, author, publisher, isbn, dPublished, description, page, shelfNo, bookCover, bookImg, bookCategory);
		
		Add_NewBook.main(null);
		this.setVisible(false);
		
	}
	private void setComboBoxShelf(JComboBox comboBox) {
		for(var s : DAOProduct.getAllShelf()) {
			comboBox.addItem(s.getShelfName());
		}
		}
	private static JToolTip createCustomToolTip() {
		var toolTip = new JToolTip();
		toolTip.setBackground(new Color(255,253,239));
		toolTip.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
		toolTip.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		return toolTip;		
	}
	
	protected void textFieldMouseEntered(MouseEvent e) {
		txtBookImg.setToolTipText("Please use semicolon (;) to separate the links.");
	}
	protected void btnCoverActionPerformed(ActionEvent e) {
		getCoverLink();
	}
	protected void btnImageActionPerformed(ActionEvent e) {
		multipleImgs();
	}
	
	protected void btnCancelActionPerformed(ActionEvent e) {
		var result = JOptionPane.showConfirmDialog(null, "Unsave record will be discarded. Do you want to cancel?", "Confirmation", JOptionPane.YES_NO_OPTION);
		switch (result) {
		case JOptionPane.YES_OPTION:
			this.dispose();
			this.setVisible(false);
		case JOptionPane.NO_OPTION:
			break;
		}
	}
	protected void btnSelectActionPerformed(ActionEvent e) {
		var cardLayout = (CardLayout) contentPane.getLayout();
		cardLayout.next(contentPane);
	}
	protected void btnGenreCancelActionPerformed(ActionEvent e) {
		Back();
	}
	protected void btnGenreOKActionPerformed(ActionEvent e) {
		bookGenre = getGenres(panel_3);
		txtBookGenre.setText(bookGenre);
		Back();
	}
	
	private void Back() {
		var cardLayout = (CardLayout) contentPane.getLayout();
		cardLayout.previous(contentPane);
	}
	private void chooseBookGenres(JPanel panel) {
		for(var cat : DAOProduct.getAllCategory()) {
			var chkbox = new JCheckBox();
			chkbox.setText(cat.getCategoryName());
			chkbox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
			chkbox.setForeground(new Color(105,105,105));
			panel.add(chkbox);
		}
	}
	
	private String getGenres(JPanel panel) {
		String genres = "";
		
		Component[] component = panel.getComponents();
		var j = 0;
		for(int i = 0; i < component.length; i++) {
			JCheckBox chkbox = (JCheckBox) component[i];
			if(chkbox.isSelected()) {
				if(j == 0) {
					genres += chkbox.getText();
				} else {
					genres += "; " + chkbox.getText();
				}
				j++;
			}	
		}
		
		return genres;
	}
}
