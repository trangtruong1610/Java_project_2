package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.JScrollPane;
import javax.swing.border.SoftBevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import dao.DAOProduct;

import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.SystemColor;

public class Add_NewCopy extends JFrame {

	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JButton btnAdd_copy;
	private JLabel lblBookID;
	private JTextField txtBookID_date;
	private JTextField txtBookID_BookNo;
	private JLabel lblBookID_Sep1;
	private JTextField txtBookID_No;
	private JLabel lblBookID_Sep2;
	private JButton btnBack;
	private static String bookNo;
	private static int book_no;
	private JTable table;
	private JButton btnDelete_copy;
	private static String accountNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if(args.length != 0) {
			accountNo = args[0];
			bookNo = args[1];
		} else {
			accountNo = null;
			bookNo = "2";
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_NewCopy frame = new Add_NewCopy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_NewCopy() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 480);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		book_no = Integer.parseInt(bookNo);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setBackground(new Color(245, 245, 245));
		scrollPane.setBounds(24, 143, 656, 267);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		btnAdd_copy = new JButton("");
		btnAdd_copy.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnAdd_copy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAdd_copyActionPerformed(e);
			}
		});
		btnAdd_copy.setBackground(new Color(244, 164, 96));
		btnAdd_copy.setBounds(567, 82, 40, 40);
		contentPane.add(btnAdd_copy);
		
		lblBookID = new JLabel("Book ID");
		lblBookID.setForeground(new Color(245, 245, 245));
		lblBookID.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		lblBookID.setBounds(42, 90, 65, 23);
		contentPane.add(lblBookID);
		
		txtBookID_date = new JTextField();
		txtBookID_date.setEditable(false);
		txtBookID_date.setHorizontalAlignment(SwingConstants.RIGHT);
		txtBookID_date.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		txtBookID_date.setBackground(new Color(245, 245, 245));
		txtBookID_date.setAutoscrolls(false);
		txtBookID_date.setBounds(124, 92, 119, 21);
		contentPane.add(txtBookID_date);
		txtBookID_date.setColumns(10);
		
		txtBookID_BookNo = new JTextField();
		txtBookID_BookNo.setEditable(false);
		txtBookID_BookNo.setHorizontalAlignment(SwingConstants.RIGHT);
		txtBookID_BookNo.setColumns(10);
		txtBookID_BookNo.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		txtBookID_BookNo.setBackground(new Color(245, 245, 245));
		txtBookID_BookNo.setAutoscrolls(false);
		txtBookID_BookNo.setBounds(265, 92, 119, 21);
		contentPane.add(txtBookID_BookNo);
		
		lblBookID_Sep1 = new JLabel("-");
		lblBookID_Sep1.setFocusable(true);
		lblBookID_Sep1.setForeground(new Color(245, 245, 245));
		lblBookID_Sep1.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblBookID_Sep1.setVerticalTextPosition(SwingConstants.CENTER);
		lblBookID_Sep1.setVerticalAlignment(SwingConstants.CENTER);
		lblBookID_Sep1.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBookID_Sep1.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookID_Sep1.setBounds(242, 93, 23, 19);
		contentPane.add(lblBookID_Sep1);
		
		txtBookID_No = new JTextField();
		txtBookID_No.setEditable(false);
		txtBookID_No.setHorizontalAlignment(SwingConstants.RIGHT);
		txtBookID_No.setColumns(10);
		txtBookID_No.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		txtBookID_No.setBackground(new Color(245, 245, 245));
		txtBookID_No.setAutoscrolls(false);
		txtBookID_No.setBounds(408, 92, 119, 21);
		contentPane.add(txtBookID_No);
		
		lblBookID_Sep2 = new JLabel("-");
		lblBookID_Sep2.setVerticalTextPosition(SwingConstants.CENTER);
		lblBookID_Sep2.setVerticalAlignment(SwingConstants.CENTER);
		lblBookID_Sep2.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBookID_Sep2.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookID_Sep2.setForeground(new Color(245, 245, 245));
		lblBookID_Sep2.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblBookID_Sep2.setFocusable(true);
		lblBookID_Sep2.setBounds(383, 93, 23, 19);
		contentPane.add(lblBookID_Sep2);
		
		btnBack = new JButton("Back");
		btnBack.setForeground(new Color(245, 245, 245));
		btnBack.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnBackActionPerformed(e);
			}
		});
		btnBack.setBackground(new Color(255, 140, 0));
		btnBack.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		btnBack.setBounds(24, 35, 89, 23);
		contentPane.add(btnBack);
		btnBack.setContentAreaFilled(true);
		btnAdd_copy.setIcon(setBtnImg("plus.png"));
		btnAdd_copy.setContentAreaFilled(true);
		
		
		btnDelete_copy = new JButton("");
		btnDelete_copy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnDelete_copyActionPerformed(e);
			}
		});
		btnDelete_copy.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnDelete_copy.setBackground(new Color(244, 164, 96));
		btnDelete_copy.setBounds(615, 81, 40, 40);
		btnDelete_copy.setIcon(setBtnImg("cmyk-blue.png"));
		btnDelete_copy.setContentAreaFilled(true);
		
		contentPane.add(btnDelete_copy);
		
		setText();
		loadTable();
	}
	
	private void setText() {
		var now = LocalDateTime.now();
		var year = now.getYear();
		String month = "";
		var m = now.getMonthValue();
		if(m < 10) {
			month = "0" + Integer.toString(m);
		} else {
			month = Integer.toString(m);
		}
		var bookID_date = Integer.toString(year) + month;
		txtBookID_date.setText(bookID_date);
	
		var bookNo_fm = new DecimalFormat("0000");
		var b_No = bookNo_fm.format(book_no);		
		txtBookID_BookNo.setText(b_No);
		
		var copyNo_fm = new DecimalFormat("00");
		var noCopy = DAOProduct.getCopyNo(book_no) + 1;
		var copy_No = copyNo_fm.format(noCopy);
		txtBookID_No.setText(copy_No);
		
	}
	
	private void loadTable() {
		var tableMode = new DefaultTableModel();
		tableMode.addColumn("No");
		tableMode.addColumn("Book ID");
		tableMode.addColumn("Status");
		
		var status = "Available";
		var item_no = 1;
		
		for(var item : DAOProduct.getBookItem(book_no)) {
			if(item.isStatus() == false) {
				status = "Lent";
			}
			
			tableMode.addRow(new Object[] {
				item_no,
				item.getBookID(),
				status
			});
			item_no++;
		}
		
		table.setModel(tableMode);
		tableColResize(table);
	}
	
	private void tableColResize(JTable table) {
		int width = 0;
		int cols = table.getColumnCount();
		
		for (int column = 0; column < cols; column++) {
			
			for (int row = 0; row < table.getRowCount(); row++) {
			    TableCellRenderer renderer = table.getCellRenderer(row, column);
			    Component comp = table.prepareRenderer(renderer, row, column);
			    width = Math.max(comp.getPreferredSize().width, width);
			}
			
			if(column == 0 || column == 2) {
				table.getColumnModel().getColumn(column).setMinWidth(100);
				table.getColumnModel().getColumn(column).setMaxWidth(width);
			}
		}
	}
	
	private ImageIcon setBtnImg(String source_img) {
		var path = "image/icons/" + source_img;
		Image img = new ImageIcon(path).getImage().getScaledInstance(40, 40, Image.SCALE_SMOOTH);
		var icon = new ImageIcon(img);
		return icon;
	}
	protected void btnAdd_copyActionPerformed(ActionEvent e) {
		var bookID = txtBookID_date.getText() + lblBookID_Sep1.getText() + txtBookID_BookNo.getText() + lblBookID_Sep2.getText() + txtBookID_No.getText();
		
		DAOProduct.AddCopy(book_no, bookID);
		loadTable();
	}
	
	protected void btnBackActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountNo;
		Home_AdminHome.main(arr);
		this.setVisible(false);
	}
	
	protected void btnDelete_copyActionPerformed(ActionEvent e) {
		var result = table.getSelectionModel().isSelectionEmpty();
		var value = table.getValueAt(table.getSelectedRow(), 1);
		var bookID = value.toString();
		
		if(!result) {
			DAOProduct.deleteCopy(bookID);
		} else {
			var msg = "Please choose a copy to delete.";
			JOptionPane.showMessageDialog(null, msg);
		}
			
		loadTable();
	}
}
