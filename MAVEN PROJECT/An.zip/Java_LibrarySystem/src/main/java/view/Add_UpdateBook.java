package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.filechooser.FileFilter;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.CardLayout;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.JToolTip;

import com.toedter.calendar.JDateChooser;

import common.Convertor;
import dao.DAOProduct;
import view.Add_NewBook.FileTypeFilter;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.GridLayout;

public class Add_UpdateBook extends JFrame {

	private JPanel contentPane;
	private static String accountName;
	private static String bookNo;
	private int book_no;
	private JPanel panelDetail;
	private JLabel lblTitle;
	private JLabel lblAuthor;
	private JLabel lblPublisher;
	private JLabel lblIsbn;
	private JLabel lblDate;
	private JLabel lblGenre;
	private JLabel lblPages;
	private JLabel lblShelf;
	private JLabel lblBookCover;
	private JLabel lblBookImg;
	private JLabel lblDescription;
	private JTextField txtISBN;
	private JDateChooser dateChooser;
	private JTextField txtTitle;
	private JPanel panel;
	private JLabel lblCover;
	private JTextField txtAuthor;
	private JTextField txtPublisher;
	private JTextField txtPage;
	private JComboBox comboBox;
	private JButton btnGenre;
	private JButton btnCover;
	private JButton btnImg;
	private JTextField txtCover;
	private JScrollPane scrollPane;
	private JTextArea textArea;
	private JButton btnSave;
	private JButton btnCancel;
	private JPanel panelGenre;
	private JScrollPane scrollPane_1;
	private JPanel panel_1;
	private JButton btnOK;
	private JButton btnBack;
	private static String bookGenre;
	private JLabel txtBookGenre;
	private JLabel lblBookGenre;
	private JTextField txtBookImg;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if(args.length != 0) {
			accountName = args[0];
			bookNo = args[1];
		} else {
			accountName = null;
			bookNo = "3";
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_UpdateBook frame = new Add_UpdateBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_UpdateBook() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 640);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 51, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
		
		book_no = Integer.parseInt(bookNo);
		
		panelDetail = new JPanel();
		panelDetail.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panelDetail.setBackground(new Color(51, 51, 51));
		contentPane.add(panelDetail, "panelDetail");
		panelDetail.setLayout(null);
		
		lblTitle = new JLabel("Book Title");
		lblTitle.setForeground(new Color(245, 245, 245));
		lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblTitle.setBounds(55, 29, 65, 25);
		panelDetail.add(lblTitle);
		
		lblAuthor = new JLabel("Author");
		lblAuthor.setForeground(new Color(245, 245, 245));
		lblAuthor.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblAuthor.setBounds(55, 65, 65, 25);
		panelDetail.add(lblAuthor);
		
		lblPublisher = new JLabel("Publisher");
		lblPublisher.setForeground(new Color(245, 245, 245));
		lblPublisher.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblPublisher.setBounds(55, 101, 65, 25);
		panelDetail.add(lblPublisher);
		
		lblIsbn = new JLabel("ISBN");
		lblIsbn.setForeground(new Color(245, 245, 245));
		lblIsbn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblIsbn.setBounds(55, 137, 65, 25);
		panelDetail.add(lblIsbn);
		
		lblDate = new JLabel("Published Date");
		lblDate.setForeground(new Color(245, 245, 245));
		lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblDate.setBounds(348, 137, 78, 25);
		panelDetail.add(lblDate);
		
		lblGenre = new JLabel("Genre");
		lblGenre.setForeground(new Color(245, 245, 245));
		lblGenre.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblGenre.setBounds(55, 173, 65, 25);
		panelDetail.add(lblGenre);
		
		lblPages = new JLabel("Pages");
		lblPages.setForeground(new Color(245, 245, 245));
		lblPages.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblPages.setBounds(349, 210, 78, 25);
		panelDetail.add(lblPages);
		
		lblShelf = new JLabel("Shelf");
		lblShelf.setForeground(new Color(245, 245, 245));
		lblShelf.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblShelf.setBounds(56, 210, 65, 25);
		panelDetail.add(lblShelf);
		
		lblBookCover = new JLabel("Book Cover");
		lblBookCover.setForeground(new Color(245, 245, 245));
		lblBookCover.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblBookCover.setBounds(55, 246, 65, 25);
		panelDetail.add(lblBookCover);
		
		lblBookImg = new JLabel("Book Image");
		lblBookImg.setForeground(new Color(245, 245, 245));
		lblBookImg.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblBookImg.setBounds(55, 282, 65, 25);
		panelDetail.add(lblBookImg);
		
		lblDescription = new JLabel("Description");
		lblDescription.setForeground(new Color(245, 245, 245));
		lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		lblDescription.setBounds(55, 318, 65, 25);
		panelDetail.add(lblDescription);
		
		txtISBN = new JTextField();
		txtISBN.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtISBN.setBounds(132, 140, 190, 20);
		panelDetail.add(txtISBN);
		txtISBN.setColumns(10);
		
		dateChooser = new JDateChooser();
		dateChooser.setBounds(436, 140, 190, 20);
		dateChooser.setDateFormatString("yyyy-MM-dd");
		panelDetail.add(dateChooser);
		
		txtTitle = new JTextField();
		txtTitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtTitle.setColumns(10);
		txtTitle.setBounds(132, 32, 496, 20);
		panelDetail.add(txtTitle);
		
		panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(new Color(220, 220, 220));
		panel.setBounds(679, 29, 270, 350);
		panelDetail.add(panel);
		panel.setLayout(null);
		
		lblCover = new JLabel("");
		lblCover.setHorizontalAlignment(SwingConstants.CENTER);
		lblCover.setHorizontalTextPosition(SwingConstants.CENTER);
		lblCover.setBounds(0, 0, 270, 350);
		panel.add(lblCover);
		
		txtAuthor = new JTextField();
		txtAuthor.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtAuthor.setColumns(10);
		txtAuthor.setBounds(132, 68, 496, 20);
		panelDetail.add(txtAuthor);
		
		txtPublisher = new JTextField();
		txtPublisher.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtPublisher.setColumns(10);
		txtPublisher.setBounds(132, 104, 496, 20);
		panelDetail.add(txtPublisher);
		
		txtPage = new JTextField();
		txtPage.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtPage.setColumns(10);
		txtPage.setBounds(437, 212, 190, 20);
		panelDetail.add(txtPage);
		
		comboBox = new JComboBox();
		comboBox.setBounds(132, 212, 189, 23);
		panelDetail.add(comboBox);
		
		btnGenre = new JButton("Select");
		btnGenre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnGenreActionPerformed(e);
			}
		});
		btnGenre.setBackground(new Color(255, 140, 0));
		btnGenre.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnGenre.setForeground(new Color(220, 220, 220));
		btnGenre.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnGenre.setBounds(132, 174, 89, 23);
		panelDetail.add(btnGenre);
		
		btnCover = new JButton("Choose File");
		btnCover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCoverActionPerformed(e);
			}
		});
		btnCover.setForeground(new Color(220, 220, 220));
		btnCover.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnCover.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCover.setBackground(new Color(255, 140, 0));
		btnCover.setBounds(132, 248, 89, 23);
		panelDetail.add(btnCover);
		
		btnImg = new JButton("Choose Files");
		btnImg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnImgActionPerformed(e);
			}
		});
		btnImg.setForeground(new Color(220, 220, 220));
		btnImg.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnImg.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnImg.setBackground(new Color(255, 140, 0));
		btnImg.setBounds(132, 284, 89, 23);
		panelDetail.add(btnImg);
		
		txtCover = new JTextField();
		txtCover.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtCover.setColumns(10);
		txtCover.setBounds(229, 249, 397, 20);
		panelDetail.add(txtCover);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(130, 318, 496, 174);
		panelDetail.add(scrollPane);
		
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		scrollPane.setViewportView(textArea);
		
		btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnSaveActionPerformed(e);
			}
		});
		btnSave.setForeground(new Color(220, 220, 220));
		btnSave.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnSave.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnSave.setBackground(new Color(30, 144, 255));
		btnSave.setBounds(55, 524, 89, 23);
		panelDetail.add(btnSave);
		
		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCancelActionPerformed(e);
			}
		});
		btnCancel.setForeground(new Color(220, 220, 220));
		btnCancel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		btnCancel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCancel.setBackground(new Color(30, 144, 255));
		btnCancel.setBounds(180, 524, 89, 23);
		panelDetail.add(btnCancel);
		
		txtBookGenre = new JLabel("");
		txtBookGenre.setForeground(new Color(245, 245, 245));
		txtBookGenre.setFont(new Font("Segoe UI Semibold", Font.ITALIC, 11));
		txtBookGenre.setBounds(231, 173, 397, 25);
		panelDetail.add(txtBookGenre);
		
		panelGenre = new JPanel();
		panelGenre.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panelGenre.setBackground(new Color(51, 51, 51));
		contentPane.add(panelGenre, "panelGenre");
		panelGenre.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane_1.setBackground(new Color(204, 204, 204));
		scrollPane_1.setBounds(69, 111, 859, 399);
		panelGenre.add(scrollPane_1);
		
		panel_1 = new JPanel();
		scrollPane_1.setViewportView(panel_1);
		panel_1.setBorder(new EmptyBorder(50, 50, 50, 50));
		panel_1.setLayout(new GridLayout(0, 4, 20, 20));
		
		btnOK = new JButton("OK");
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnOKActionPerformed(e);
			}
		});
		btnOK.setBounds(69, 535, 89, 23);
		panelGenre.add(btnOK);
		
		btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnBackActionPerformed(e);
			}
		});
		btnBack.setBounds(195, 535, 89, 23);
		panelGenre.add(btnBack);
		setComboBoxShelf(comboBox);
		
		txtBookImg = new JTextField();
		txtBookImg.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		txtBookImg.setColumns(10);
		txtBookImg.setBounds(229, 285, 397, 20);
		panelDetail.add(txtBookImg);
		chooseBookGenres(panel_1);
		getGenres(panel_1);
		
		lblBookGenre = new JLabel("Book Genre");
		lblBookGenre.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBookGenre.setHorizontalAlignment(SwingConstants.CENTER);
		lblBookGenre.setForeground(new Color(245, 245, 245));
		lblBookGenre.setFont(new Font("Elephant", Font.BOLD, 35));
		lblBookGenre.setBackground(Color.WHITE);
		lblBookGenre.setBounds(38, 50, 922, 35);
		panelGenre.add(lblBookGenre);
		
		showBookRecord();
	}
	
	private String get_BookImg(List<String> imgList) {
		var bookImgLink = "";
		var i = 0;
		var list = imgList;
		for(var img : list) {
			if(i == 0) {
				bookImgLink += img;
			} else {
				bookImgLink += "; " + img;
			}
			i++;
		}
		
		return bookImgLink;
		
	}
	
	private String getBookGenre(List<String> genreList) {
		var currentGenre = "";
		var i = 0;
		var list = genreList;
		for(var genre : list) {
			if(i == 0) {
				currentGenre += genre;
			} else {
				currentGenre += "; " + genre;
			}
			i++;
		}
		
		return currentGenre;
	}
	
	private void showBookRecord() {
		for(var record : DAOProduct.getBookRecord(book_no)) {
			setTitle(record.getTitle());
			var path = DAOProduct.getBookCover(book_no);
			
			txtTitle.setText(record.getTitle());
			txtAuthor.setText(record.getAuthor());
			txtPublisher.setText(record.getISBN());
			txtISBN.setText(record.getISBN());
			textArea.setText(record.getDescription());
			txtCover.setText(path);
			txtBookImg.setText(get_BookImg(DAOProduct.getImgLink(book_no)));
			dateChooser.setDate(record.getYPublished());
			txtPage.setText(Integer.toString(record.getPages()));
			txtBookGenre.setText(getBookGenre(DAOProduct.getCurrentGenre(book_no)));
			comboBox.getModel().setSelectedItem(DAOProduct.getShelf(record.getShelfNo()));
						
			var convert = new Convertor();
			var img = convert.loadImg(path);
			var newH = 350;
			var newW = convert.resizeImageWRatioH(img, newH);
			var cover = new ImageIcon(img).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
			lblCover.setIcon(new ImageIcon(cover));
			lblCover.setHorizontalAlignment(SwingConstants.CENTER);
			lblCover.setVerticalAlignment(SwingConstants.CENTER);		
		}
		
	}
	
	private void getCoverLink() {
		
		var jfile = new JFileChooser();
//		jfile.setCurrentDirectory(new File(System.getProperty("user.home")));
		
		jfile.setCurrentDirectory(new File("D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image"));
		FileFilter png = new FileTypeFilter(".png","Portable Network Graphics");
		FileFilter jpg = new FileTypeFilter(".jpg", "Joint Photographic Experts Group");
		FileFilter jpeg = new FileTypeFilter(".jpeg", "Joint Photographic Experts Group");
		FileFilter tiff = new FileTypeFilter(".tiff", "Tagged Image File Format");
		jfile.setFileFilter(png);
		jfile.setFileFilter(jpg);
		jfile.setFileFilter(jpeg);
		jfile.setFileFilter(tiff);
		
		jfile.setAcceptAllFileFilterUsed(false);
		
		jfile.setDialogTitle("Choose Book Cover");
		int result = jfile.showOpenDialog(this);
		if(result == JFileChooser.APPROVE_OPTION) {
			var convert = new Convertor();
			var path = jfile.getSelectedFile().getAbsolutePath();
			var img = convert.loadImg(path);
			var newH = 350;
			var newW = convert.resizeImageWRatioH(img, newH);
			var cover = new ImageIcon(img).getImage().getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
			lblCover.setIcon(new ImageIcon(cover));
			lblCover.setHorizontalAlignment(SwingConstants.CENTER);
			lblCover.setVerticalAlignment(SwingConstants.CENTER);
			txtCover.setText("");
			txtCover.setText(path);
		}
	}
	
	private void multipleImgs() {
		var txt = "";
			
		var jfile = new JFileChooser();
//		jfile.setCurrentDirectory(new File(System.getProperty("user.home")));
		
		jfile.setCurrentDirectory(new File("D:\\Studies\\Aptech\\Java\\eclipse-workspace\\Java_LibrarySystem\\image"));
		
		FileFilter png = new FileTypeFilter(".png","Portable Network Graphics");
		FileFilter jpg = new FileTypeFilter(".jpg", "Joint Photographic Experts Group");
		FileFilter jpeg = new FileTypeFilter(".jpeg", "Joint Photographic Experts Group");
		FileFilter tiff = new FileTypeFilter(".tiff", "Tagged Image File Format");
		jfile.setFileFilter(png);
		jfile.setFileFilter(jpg);
		jfile.setFileFilter(jpeg);
		jfile.setFileFilter(tiff);
		
		jfile.setAcceptAllFileFilterUsed(false);
		jfile.setMultiSelectionEnabled(true);
		
		jfile.setDialogTitle("Choose Book Images");
		int result = jfile.showOpenDialog(this);
		
		if(result == JFileChooser.APPROVE_OPTION) {
			File[] files = jfile.getSelectedFiles();
			
			for(var file : files) {
				var file_path = file.getAbsolutePath();
				txt += file_path + ";";
			}
			txtBookImg.setText("");
			txtBookImg.setText(txt);
		}
	}
			
	public class FileTypeFilter extends FileFilter {
	    private String extension;
	    private String description;
	 
	    public FileTypeFilter(String extension, String description) {
	        this.extension = extension;
	        this.description = description;
	    }
	    
	    
	 
	    public boolean accept(File file) {
	        if (file.isDirectory()) {
	            return true;
	        }
	        return file.getName().endsWith(extension);
	    }
	 
	    public String getDescription() {
	        return description + String.format(" (*%s)", extension);
	    }
	}

	private void setComboBoxShelf(JComboBox comboBox) {
		
		for(var s : DAOProduct.getAllShelf()) {
			comboBox.addItem(s.getShelfName());
		}
		
	}
	
	private static JToolTip createCustomToolTip() {
		var toolTip = new JToolTip();
		toolTip.setBackground(new Color(255,253,239));
		toolTip.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 12));
		toolTip.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		return toolTip;		
	}
	
	private void chooseBookGenres(JPanel panel) {
		var stringGenre = DAOProduct.getCurrentGenre(book_no);
		for(var cat : DAOProduct.getAllCategory()) {
			
			var chkbox = new JCheckBox();
			chkbox.setText(cat.getCategoryName());
			for(var i : stringGenre) {
				if(cat.getCategoryName().equalsIgnoreCase(i)) {
					chkbox.setSelected(true);
				}
			}
		
		chkbox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		chkbox.setForeground(new Color(105,105,105));
		panel.add(chkbox);
		}
		
	}
	
	private String getGenres(JPanel panel) {
		String genres = "";
		
		Component[] component = panel.getComponents();
		var j = 0;
		for(int i = 0; i < component.length; i++) {
			JCheckBox chkbox = (JCheckBox) component[i];
			if(chkbox.isSelected()) {
				if(j == 0) {
					genres += chkbox.getText();
				} else {
					genres += "; " + chkbox.getText();
				}
				j++;
			}	
		}
		
		return genres;
	}
	
	private void Back() {
		var cardLayout = (CardLayout) contentPane.getLayout();
		cardLayout.first(contentPane);
	}
	
	protected void btnGenreActionPerformed(ActionEvent e) {
		var cardLayout = (CardLayout) contentPane.getLayout();
		cardLayout.next(contentPane);
	}
	protected void btnCoverActionPerformed(ActionEvent e) {
		getCoverLink();
	}
	
	protected void btnSaveActionPerformed(ActionEvent e) {
		var n_title = txtTitle.getText();
		var n_author = txtAuthor.getText();
		var n_publisher = txtPublisher.getText();
		var n_isbn = txtISBN.getText();
		var n_page = Integer.parseInt(txtPage.getText());
		var n_description = textArea.getText();
		var n_bookCover = txtCover.getText();
		var bookImgLink = txtBookImg.getText();
		var n_genre = txtBookGenre.getText();
		var n_shelfno = DAOProduct.getShelfNo(comboBox.getSelectedItem().toString());
		var n_dPublished = dateChooser.getDate().toString();
		
		DAOProduct.updateBook(book_no, n_title, n_author, n_publisher, n_isbn, n_dPublished, n_description, n_page, n_shelfno, n_bookCover, n_genre, bookImgLink);
	}
	protected void btnImgActionPerformed(ActionEvent e) {
		multipleImgs();
	}
	
	protected void btnCancelActionPerformed(ActionEvent e) {
		int result = JOptionPane.showConfirmDialog(null, "Unsave record will be discarded. Do you still want to cancel?", "Confirmation", JOptionPane.YES_NO_OPTION);
		switch(result) {
		case JOptionPane.YES_OPTION:
			this.setVisible(false);
		case JOptionPane.NO_OPTION:
			break;
		}
	}
	
	protected void btnBackActionPerformed(ActionEvent e) {
		Back();
	}
	protected void btnOKActionPerformed(ActionEvent e) {
		bookGenre = getGenres(panel_1);
		txtBookGenre.setText(bookGenre);
		Back();
	}
}