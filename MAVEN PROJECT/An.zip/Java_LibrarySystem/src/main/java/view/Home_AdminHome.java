package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import dao.DAOProduct;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.border.BevelBorder;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Dimension;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.BoxLayout;
import javax.swing.DefaultRowSorter;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home_AdminHome extends JFrame {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JButton btnHome;
	private JButton btnAccount;
	private JButton btnLogout;
	private JScrollPane scrollPane;
	private JPanel panel_Book;
	private JPanel panelBook;
	private JButton btnAdd;
	private JButton btnCopyManage;
	private JButton btnUpdate;
	private JButton btnDeleteBook;
	private JLabel lblBookMenu;
	private JPanel panel_Account;
	private JLabel lblAccountMenu;
	private JPanel panelAccount;
	private JButton btnAccountManagement;
	private JButton btnLendingList;
	private JButton btnReservation;
	private JTable table;
	private JLabel lblBook;
	private JLabel lblWelcome;
	private static String accountName;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		if (args.length != 0) {
			accountName = args[0];
		} else {
			accountName = null;
		}
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home_AdminHome frame = new Home_AdminHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home_AdminHome() {
		setTitle("Admin Homepage");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 720);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		setIconImage(new ImageIcon("image/icons/logo.png").getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH));
		
		menuBar = new JMenuBar();
		menuBar.setBackground(new Color(105, 105, 105));
		setJMenuBar(menuBar);
		
		btnHome = new JButton("Homepage");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnHomeActionPerformed(e);
			}
		});
		btnHome.setForeground(new Color(255, 255, 255));
		btnHome.setBackground(new Color(105, 105, 105));
		menuBar.add(btnHome);
		
		btnAccount = new JButton("Account");
		btnAccount.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAccountActionPerformed(e);
			}
		});
		btnAccount.setForeground(Color.WHITE);
		btnAccount.setBackground(SystemColor.controlDkShadow);
		menuBar.add(btnAccount);
		
		btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLogoutActionPerformed(e);
			}
		});
		btnLogout.setForeground(Color.WHITE);
		btnLogout.setBackground(SystemColor.controlDkShadow);
		menuBar.add(btnLogout);
		
		contentPane = new JPanel();
		contentPane.setBackground(new Color(105, 105, 105));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		scrollPane = new JScrollPane();
		scrollPane.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		scrollPane.setBackground(new Color(245, 245, 245));
		
		panel_Book = new JPanel();
		
		panel_Account = new JPanel();
		panel_Account.setLayout(new BorderLayout(0, 0));
		
		lblWelcome = new JLabel("");
		lblWelcome.setText(setWelcomeTxt());
		lblWelcome.setForeground(new Color(245, 245, 245));
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblWelcome.setBorder(new EmptyBorder(0, 5, 0, 0));
		
		textField = new JTextField();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldActionPerformed(e);
			}
		});
		textField.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(panel_Book, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
							.addComponent(panel_Account, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
						.addComponent(lblWelcome, GroupLayout.PREFERRED_SIZE, 215, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 428, GroupLayout.PREFERRED_SIZE)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 757, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblWelcome, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 585, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(panel_Book, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(panel_Account, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		
		table = new JTable();
		table.setBackground(new Color(245, 245, 245));
		table.setGridColor(new Color(192, 192, 192));
		table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		scrollPane.setViewportView(table);
		
		lblBook = new JLabel("BOOK LIST");
		lblBook.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBook.setHorizontalAlignment(SwingConstants.CENTER);
		lblBook.setForeground(new Color(25, 25, 112));
		lblBook.setFont(new Font("Elephant", Font.BOLD, 20));
		lblBook.setBorder(new EmptyBorder(5, 0, 5, 0));
		scrollPane.setColumnHeaderView(lblBook);
		
		lblAccountMenu = new JLabel("Account Menu");
		lblAccountMenu.setHorizontalTextPosition(SwingConstants.CENTER);
		lblAccountMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblAccountMenu.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblAccountMenu.setBorder(new EmptyBorder(7, 5, 2, 5));
		lblAccountMenu.setBackground(new Color(220, 220, 220));
		panel_Account.add(lblAccountMenu, BorderLayout.NORTH);
		
		panelAccount = new JPanel();
		panelAccount.setLayout(null);
		panelAccount.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panelAccount.setBackground(new Color(245, 245, 245));
		panel_Account.add(panelAccount, BorderLayout.CENTER);
		
		btnAccountManagement = new JButton("Account Management");
		btnAccountManagement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAccountManagementActionPerformed(e);
			}
		});
		btnAccountManagement.setForeground(Color.WHITE);
		btnAccountManagement.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnAccountManagement.setContentAreaFilled(true);
		btnAccountManagement.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnAccountManagement.setBackground(Color.GRAY);
		btnAccountManagement.setBounds(10, 11, 195, 23);
		panelAccount.add(btnAccountManagement);
		
		btnLendingList = new JButton("Lending List");
		btnLendingList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnLendingListActionPerformed(e);
			}
		});
		btnLendingList.setForeground(Color.WHITE);
		btnLendingList.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnLendingList.setContentAreaFilled(true);
		btnLendingList.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnLendingList.setBackground(Color.GRAY);
		btnLendingList.setBounds(10, 79, 195, 23);
		panelAccount.add(btnLendingList);
		
		btnReservation = new JButton("Reservation List");
		btnReservation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnReservationActionPerformed(e);
			}
		});
		btnReservation.setForeground(Color.WHITE);
		btnReservation.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnReservation.setContentAreaFilled(true);
		btnReservation.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnReservation.setBackground(Color.GRAY);
		btnReservation.setBounds(10, 45, 195, 23);
		panelAccount.add(btnReservation);
		panel_Book.setLayout(new BorderLayout(0, 0));
		
		panelBook = new JPanel();
		panelBook.setLayout(null);
		panelBook.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panelBook.setBackground(new Color(245, 245, 245));
		panel_Book.add(panelBook, BorderLayout.CENTER);
		
		btnAdd = new JButton("Add Book");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAddActionPerformed(e);
			}
		});
		btnAdd.setForeground(new Color(255, 255, 255));
		btnAdd.setBackground(new Color(128, 128, 128));
		btnAdd.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnAdd.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnAdd.setBounds(10, 11, 91, 23);
		panelBook.add(btnAdd);
		
		btnCopyManage = new JButton("Book Copy");
		btnCopyManage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnAddCopyActionPerformed(e);
			}
		});
		btnCopyManage.setForeground(new Color(255, 255, 255));
		btnCopyManage.setBackground(new Color(128, 128, 128));
		btnCopyManage.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnCopyManage.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnCopyManage.setBounds(10, 80, 91, 23);
		panelBook.add(btnCopyManage);
		
		btnUpdate = new JButton("Update Book");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnUpdateActionPerformed(e);
			}
		});
		btnUpdate.setForeground(new Color(255, 255, 255));
		btnUpdate.setBackground(new Color(128, 128, 128));
		btnUpdate.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnUpdate.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnUpdate.setBounds(111, 11, 91, 23);
		panelBook.add(btnUpdate);
		
		btnDeleteBook = new JButton("Delete Book");
		btnDeleteBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnDeleteBookActionPerformed(e);
			}
		});
		btnDeleteBook.setForeground(new Color(255, 255, 255));
		btnDeleteBook.setBackground(new Color(128, 128, 128));
		btnDeleteBook.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnDeleteBook.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
		btnDeleteBook.setBounds(10, 45, 91, 23);
		panelBook.add(btnDeleteBook);
		
		lblBookMenu = new JLabel("Book Menu");
		lblBookMenu.setBorder(new EmptyBorder(7, 5, 2, 5));
		lblBookMenu.setBackground(new Color(220, 220, 220));
		lblBookMenu.setFont(new Font("Sylfaen", Font.BOLD, 18));
		lblBookMenu.setHorizontalTextPosition(SwingConstants.CENTER);
		lblBookMenu.setHorizontalAlignment(SwingConstants.CENTER);
		panel_Book.add(lblBookMenu, BorderLayout.NORTH);
		contentPane.setLayout(gl_contentPane);
		
		btnAdd.setContentAreaFilled(true);
		btnCopyManage.setContentAreaFilled(true);
		btnDeleteBook.setContentAreaFilled(true);
		btnUpdate.setContentAreaFilled(true);
		
		setTableContent(table);
		table.setAutoCreateRowSorter(true);
	}
	
	protected void setTableContent(JTable table) {
		var model = new DefaultTableModel();
		model.addColumn("No");
		model.addColumn("Book Title");
		model.addColumn("Author");
		model.addColumn("ISBN");
		model.addColumn("Publisher");
		model.addColumn("On Shelf");
		model.addColumn("Book Copies");
		model.addColumn("Book Status");
		
		for(var book : DAOProduct.getAllBook()) {
			String status;
			if(book.isStatus() == true) {
				status = "Available";
			} else {
				status = "Unavailable";
			}
			
			model.addRow(new Object[] {
					book.getBookNo(),
					book.getTitle(),
					book.getAuthor(),
					book.getISBN(),
					book.getPublisher(),
					DAOProduct.getShelf(book.getShelfNo()),
					DAOProduct.getCopyNo(book.getBookNo()),
					status
			});
		}
		
		table.setModel(model);
		
		var renderer = (DefaultTableCellRenderer) table.getDefaultRenderer(String.class);
		renderer.setHorizontalAlignment(SwingConstants.CENTER);	
		ResizeTableCol(table);
		table.setRowHeight(20);
	}
	
	private void ResizeTableCol(JTable var_table) {
		
		int width = 0;
		int cols = var_table.getColumnCount();
		
		for (int column = 0; column < cols; column++) {
			
			for (int row = 0; row < var_table.getRowCount(); row++) {
			    TableCellRenderer renderer = var_table.getCellRenderer(row, column);
			    Component comp = table.prepareRenderer(renderer, row, column);
			    width = Math.max(comp.getPreferredSize().width, width);
			}
			
			if(column == 0 || column == 5 || column == 6 || column == 7) {
				var_table.getColumnModel().getColumn(column).setMinWidth(70);
				var_table.getColumnModel().getColumn(column).setMaxWidth(width);
			} else if (column == 2 || column == 3 || column == 4)
			{
				var_table.getColumnModel().getColumn(column).setMinWidth(110);
				var_table.getColumnModel().getColumn(column).setMaxWidth(width);
				}
			}
	}
	
	private String setWelcomeTxt() {
		var welcomeTxt = "Welcome, " + accountName;
		return welcomeTxt;
	}
	
	private void checkSelection() {
		var msg = "";
		var check = table.getSelectionModel().isSelectionEmpty();
		
		if(check == true) {
			msg = "Please select a book.";
		}
		
		JOptionPane.showMessageDialog(null, msg);
	}
	
	protected void btnAddActionPerformed(ActionEvent e) {
		Add_NewBook.main(null);
	}
	protected void btnAddCopyActionPerformed(ActionEvent e) {
		checkSelection();
		
		var bookNo = table.getValueAt(table.getSelectedRow(), 0).toString();
		String[] arr = new String[2];
		arr[0] = accountName;
		arr[1] = bookNo;
		
		Add_NewCopy.main(arr);
	}
	protected void btnDeleteBookActionPerformed(ActionEvent e) {
		var result = table.getSelectionModel().isSelectionEmpty();
		var value = table.getValueAt(table.getSelectedRow(), 0);
		var bookNo = Integer.parseInt(value.toString());
		
		if(!result) {
			DAOProduct.deleteBook(bookNo);
		} else {
			var msg = "Please select a book to delete";
			JOptionPane.showMessageDialog(null, msg);
		}
	}
	
	protected void btnUpdateActionPerformed(ActionEvent e) {
		var result = table.getSelectionModel().isSelectionEmpty();
		if(!result) {
			var bookNo = table.getValueAt(table.getSelectedRow(), 0);
			
			String[] arr = new String[2];
			arr[0] = accountName;
			arr[1] = bookNo.toString();
			
			Add_UpdateBook.main(arr);
		} else {
			JOptionPane.showMessageDialog(null, "Please select a book to update");
		}
	}
	
	protected void btnLendingListActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		
		lendingHistory.main(arr);
	}
	
	protected void btnReservationActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		
		bookRequest.main(arr);
	}
	
	protected void btnAccountManagementActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		Account_AccountManagement.main(arr);
	}
	
	protected void textFieldActionPerformed(ActionEvent e) {
		String search = textField.getText();
		DefaultRowSorter<?, ?> sorter = (DefaultRowSorter<?,?>) table.getRowSorter();
		sorter.setRowFilter(RowFilter.regexFilter("(?i)" + search));
		sorter.setSortKeys(null);
		textField.setText("");
	}
	protected void btnAccountActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		Account_MemberPage.main(arr);
		this.setVisible(false);
	}
	
	protected void btnHomeActionPerformed(ActionEvent e) {
		String[] arr = new String[1];
		arr[0] = accountName;
		Home_LibraryHome.main(arr);
		this.setVisible(false);
	}
	
	protected void btnLogoutActionPerformed(ActionEvent e) {
		String[] arr = new String[0];
		Home_LibraryHome.main(arr);
		this.setVisible(false);
	}
}
