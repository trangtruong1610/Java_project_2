package dao;

import java.sql.*;
import java.util.*;

import javax.swing.JOptionPane;

import common.ConnectToProperties;
import entity.*;

public class DAOProduct {
	
	public static List<Category> DisplayCategory() {
		List<Category> listCategory = new ArrayList<Category>();
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call LoadCategory}");
				var rs = ps.executeQuery();
					) {
				while(rs.next()) {
					var b_category = new Category();
					b_category.setCategoryNo(rs.getInt("CategoryNo"));
					b_category.setCategoryName(rs.getString("CategoryName"));
					listCategory.add(b_category);
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		
		return listCategory;
		
	}
	
	public static List<BookDetail> DisplayAllBook() {
		List<BookDetail> ListBook = new ArrayList<BookDetail>();
		
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call DisplayAllBook}");
				var rs = ps.executeQuery();
					) {
				while(rs.next()) {
					var b_detail = new BookDetail();
					b_detail.setBookNo(rs.getInt("BookNo"));
					b_detail.setTitle(rs.getString("Title"));
					b_detail.setAuthor(rs.getString("Author"));
					b_detail.setISBN(rs.getString("ISBN"));
					b_detail.setPublisher(rs.getString("Publisher"));
					b_detail.setPages(rs.getInt("Pages"));
					b_detail.setYPublished(rs.getDate("YPublished"));
					b_detail.setCopies(rs.getInt("Copies"));
					b_detail.setShelfNo(rs.getInt("ShelfNo"));
					b_detail.setStatus(rs.getBoolean("Status"));
					ListBook.add(b_detail);
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
			
		return ListBook;
	}
	
	public static String DisplayBookCover(int BookNo) {
		String img_Link = null;
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call DisplayBookCover(?)}");
			) {
				ps.setInt(1, BookNo);
				var rs = ps.executeQuery();
				
				while (rs.next()) {
					img_Link = rs.getString("Link");
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		return img_Link;
	}
	
	public static String ShelfLocation(int ShelfNo) {
		String shelf_Loc = null;
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call ShelfLocation(?)}");
			) {
				ps.setInt(1, ShelfNo);
				var rs = ps.executeQuery();
				
				while (rs.next()) {
					shelf_Loc = rs.getString("Link");
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		return shelf_Loc;
	}
	
	public static List<BookItem> LoadBookItem(int BookNo) {
		List<BookItem> bookItem = new ArrayList<BookItem>();
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call LoadBookItem(?)}");
			) {
				ps.setInt(1, BookNo);
				var rs = ps.executeQuery();
				
				while (rs.next()) {
					var book = new BookItem();
					book.setBookID(rs.getString("BookID"));
					book.setStatus(rs.getBoolean("Status"));
					bookItem.add(book);
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		return bookItem;
	}
	
	public static List<BookDetail> LoadBookRecord(int BookNo) {
		List<BookDetail> bookRecord = new ArrayList<BookDetail>();
		try(
				var connection = DriverManager.getConnection(ConnectToProperties.getConnection());
				var ps = connection.prepareCall("{Call LoadBookRecord(?)}");
			) {
				ps.setInt(1, BookNo);
				var rs = ps.executeQuery();
				
				while (rs.next()) {
					var book = new BookDetail();
					book.setBookNo(rs.getInt("BookNo"));
					book.setTitle(rs.getString("Title"));
					book.setAuthor(rs.getString("Author"));
					book.setISBN(rs.getString("ISBN"));
					book.setPublisher(rs.getString("Publisher"));
					book.setYPublished(rs.getDate("YPublished"));
					book.setShelfNo(rs.getInt("ShelfNo"));
					book.setStatus(rs.getBoolean("Status"));
					bookRecord.add(book);
				}
				
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Error!", JOptionPane.ERROR_MESSAGE);
			}
		return bookRecord;
	}
}
