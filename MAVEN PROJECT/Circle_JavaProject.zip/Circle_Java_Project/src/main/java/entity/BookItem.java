package entity;

public class BookItem {
	private int BookItemNo;
	private int BookNo;
	private String BookID;
	private Boolean Status;
	
	public BookItem() {}
	
	public BookItem(int bookItemNo, int bookNo, String bookID, Boolean status) {
		BookItemNo = bookItemNo;
		BookNo = bookNo;
		BookID = bookID;
		Status = status;
	}

	public int getBookItemNo() {
		return BookItemNo;
	}

	public void setBookItemNo(int bookItemNo) {
		BookItemNo = bookItemNo;
	}

	public int getBookNo() {
		return BookNo;
	}

	public void setBookNo(int bookNo) {
		BookNo = bookNo;
	}

	public String getBookID() {
		return BookID;
	}

	public void setBookID(String bookID) {
		BookID = bookID;
	}

	public Boolean getStatus() {
		return Status;
	}

	public void setStatus(Boolean status) {
		Status = status;
	}

	@Override
	public String toString() {
		return "BookItem [BookItemNo=" + BookItemNo + ", BookNo=" + BookNo + ", BookID="
				+ BookID + ", Status=" + Status + "]";
	}
}
