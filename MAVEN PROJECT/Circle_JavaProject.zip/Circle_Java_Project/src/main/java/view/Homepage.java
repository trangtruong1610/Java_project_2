package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import dao.DAOProduct;
import java.awt.GridLayout;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ListSelectionModel;

public class Homepage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnUser;
	private JMenuItem mntmLogin;
	private JSplitPane splitPane;
	private JPanel panelGenres;
	private JPanel panelData;
	private JScrollPane scrollPaneData;
	private JTextArea txtrGenres;
	private JScrollPane scrollPane_Genres;
	private JPanel panel_Genres;
	private JButton btnClear;
	private JTextField textField;
	private JButton btnSearch;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homepage frame = new Homepage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Homepage() {
		setTitle("Homepage");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 720, 480);
		
		menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.control);
		setJMenuBar(menuBar);
		
		mnUser = new JMenu("User");
		menuBar.add(mnUser);
		
		mntmLogin = new JMenuItem("Login");
		mnUser.add(mntmLogin);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		splitPane = new JSplitPane();
		splitPane.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, SystemColor.controlHighlight, SystemColor.controlHighlight, SystemColor.controlHighlight, SystemColor.controlHighlight));
		splitPane.setMinimumSize(new Dimension(150, 40));
		splitPane.setPreferredSize(new Dimension(150, 40));
		splitPane.setOneTouchExpandable(true);
		splitPane.setAlignmentX(Component.CENTER_ALIGNMENT);
		splitPane.setAlignmentY(Component.CENTER_ALIGNMENT);
		splitPane.setBackground(SystemColor.control);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(splitPane, GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(splitPane, GroupLayout.DEFAULT_SIZE, 409, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		panelGenres = new JPanel();
		panelGenres.setFont(new Font("Segoe UI", Font.PLAIN, 11));
		splitPane.setLeftComponent(panelGenres);
		
		txtrGenres = new JTextArea();
		txtrGenres.setForeground(new Color(0, 0, 128));
		txtrGenres.setFont(new Font("Elephant", Font.BOLD | Font.ITALIC, 26));
		txtrGenres.setText("Genres");
		txtrGenres.setBackground(SystemColor.control);
		
		scrollPane_Genres = new JScrollPane();
		
		btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnClearActionPerformed(e);
			}
		});
		btnClear.setBackground(SystemColor.control);
		btnClear.setForeground(Color.BLUE);
		btnClear.setFont(new Font("Segoe UI", Font.ITALIC, 12));
		btnClear.setBorderPainted(false);
		btnClear.setBorder(null);
		GroupLayout gl_panelGenres = new GroupLayout(panelGenres);
		gl_panelGenres.setHorizontalGroup(
			gl_panelGenres.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelGenres.createSequentialGroup()
					.addContainerGap()
					.addComponent(txtrGenres, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnClear)
					.addContainerGap(22, Short.MAX_VALUE))
				.addComponent(scrollPane_Genres, GroupLayout.DEFAULT_SIZE, 202, Short.MAX_VALUE)
		);
		gl_panelGenres.setVerticalGroup(
			gl_panelGenres.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panelGenres.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panelGenres.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtrGenres, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnClear))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane_Genres, GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE))
		);
		
		panel_Genres = new JPanel();
		scrollPane_Genres.setViewportView(panel_Genres);
		panel_Genres.setLayout(new GridLayout(0, 1, 1, 1));
		addCategory();
		panelGenres.setLayout(gl_panelGenres);
		
		panelData = new JPanel();
		splitPane.setRightComponent(panelData);
		
		scrollPaneData = new JScrollPane();
		
		textField = new JTextField();
		textField.setColumns(10);
		
		btnSearch = new JButton("Search");
		btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 12));
		GroupLayout gl_panelData = new GroupLayout(panelData);
		gl_panelData.setHorizontalGroup(
			gl_panelData.createParallelGroup(Alignment.LEADING)
				.addComponent(scrollPaneData, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 473, Short.MAX_VALUE)
				.addGroup(gl_panelData.createSequentialGroup()
					.addContainerGap()
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 334, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnSearch)
					.addContainerGap(56, Short.MAX_VALUE))
		);
		gl_panelData.setVerticalGroup(
			gl_panelData.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_panelData.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panelData.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSearch))
					.addGap(11)
					.addComponent(scrollPaneData, GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE))
		);
		
		table = new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		setColNonEditable(table);
		scrollPaneData.setViewportView(table);
		panelData.setLayout(gl_panelData);
		contentPane.setLayout(gl_contentPane);
		getTableContent(table);
	}
	
	private void addCategory() {
		int i = 0;
		for(var genre : DAOProduct.DisplayCategory()) {
			JCheckBox chkbox = new JCheckBox(genre.getCategoryName());
			chkbox.setFont(new Font("Segoe UI SemiBold", Font.PLAIN, 12));
			panel_Genres.add(chkbox, "cell 0 " + i);
			i++;
		}
	}
	
	private void ClearSelection() {
		Component[] component = panel_Genres.getComponents();
		
		for (int i = 0; i < component.length; i++) {
			JCheckBox chkBox = (JCheckBox) component[i];
			chkBox.setSelected(false);
		}
	}
	
	private void getTableContent(JTable table) {
		var model = (DefaultTableModel) table.getModel();
		
		Object[] Columns = new Object[] {"Book No", "Image", "Title", "Author"};
		model.setColumnIdentifiers(Columns);		

		table.getColumn("Image").setCellRenderer(new BookCover());
		
		int i = 1;
		for (var detail : DAOProduct.DisplayAllBook()) {
			
			var img_lbl = new JLabel();
			img_lbl.setHorizontalAlignment(SwingConstants.CENTER);
			
			
			var b_img = new ImageIcon(DAOProduct.DisplayBookCover(detail.getBookNo()));
			Image img = b_img.getImage().getScaledInstance(80, 100, Image.SCALE_SMOOTH);
			
			img_lbl.setIcon(new ImageIcon(img));
			
			model.addRow(new Object[] {
					i,
					img_lbl,
					detail.getTitle(),
					detail.getAuthor()
			});
			i++;
		}
		
		table.setModel(model);
		table.setRowHeight(110);
				
		var renderer = (DefaultTableCellRenderer) table.getDefaultRenderer(String.class);
		renderer.setHorizontalAlignment(SwingConstants.CENTER);	
	}
	private static class BookCover implements TableCellRenderer {
		
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {							
			
			return (Component) value;
			}
		}
	{
	}
	
	private void setColNonEditable (JTable table) {
		var non_edit = new DefaultTableModel() {
			
	        @Override
	        public boolean isCellEditable(int row, int column) {
	            return false;
	        }
	    };
	    
		table.setModel(non_edit);
	}
	
	protected void btnClearActionPerformed(ActionEvent e) {
		ClearSelection();
	}
}
