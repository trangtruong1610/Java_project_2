package common;

import java.io.FileInputStream;
import java.util.Properties;

public class ConnectToProperties {
	
	public static String getConnection() {
		
        String url = null;

        try (
                var stream = new FileInputStream ("db.properties");
                ) {
            Properties properties = new Properties();
            properties.load(stream);
            url = properties.getProperty("url")
                    + properties.getProperty("serverName") + ":"
                    + properties.getProperty("portNumber") + "; databaseName="
                    + properties.getProperty("databaseName") + "; integratedSecurity="
                    + properties.getProperty("integratedSecurity");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            url = null;
        }
        return url;
        
	}
}
	
